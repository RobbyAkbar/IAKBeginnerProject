<?php
/**
 * Created by PhpStorm.
 * User: robby
 * Date: 31/05/20
 * Time: 18:57
 */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require 'con.php';
    inputJawaban();
}

function inputJawaban() {
    global $connect;
    $id_user = $_POST["id_user"];
    $id_quiz = $_POST["id_quiz"];
    $answer = $_POST["answer"];
    $type_answer = $_POST["type"];
    $query = "INSERT INTO progressQuiz (id_user, id_quiz, answer, type_answer) VALUES ('$id_user','$id_quiz','$answer','$type_answer')";
    if (mysqli_query($connect, $query)) {
        echo "success\n";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($connect);
    }
    
    if ($type_answer=="true"){
        $sql = "UPDATE progressLearn SET progressLearn.score = progressLearn.score + 25 WHERE progressLearn.id_user = '$id_user';";
        if (mysqli_query($connect, $sql)) {
            echo "success";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }
    }
    mysqli_close($connect);
}
