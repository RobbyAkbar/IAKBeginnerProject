<?php
/**
 * Created by PhpStorm.
 * User: robby
 * Date: 02/07/19
 * Time: 06:00
 */

$conn = new PDO('mysql:host=localhost;dbname=u7050039_gisel', 'u7050039_gisel', '@tts123GiselApp');
session_start();
