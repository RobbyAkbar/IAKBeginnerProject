<?php

echo "success\n";
echo "success";

$id_lesson = 'l27';

$id = substr($id_lesson, 1);
$result = $id + '01';
echo sprintf("%s%02d", 'l', $result);

?>