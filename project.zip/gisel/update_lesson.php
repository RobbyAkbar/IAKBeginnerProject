<?php
/**
 * Created by PhpStorm.
 * User: robby
 * Date: 31/05/20
 * Time: 21:40
 */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require 'con.php';
    updateLesson();
}

function updateLesson() {
    global $connect;
    $id_user = $_POST["id_user"];
    $id_lesson = $_POST["id_lesson"];
    
    $id = substr($id_lesson, 1);
    $result = $id + '01';
    $final = sprintf("%s%02d", 'l', $result);
    
    $query = "UPDATE progressLearn SET progressLearn.dt_finish = CURRENT_TIMESTAMP WHERE progressLearn.id_user = '$id_user' AND progressLearn.id_lesson = '$id_lesson';";
    $query.= "UPDATE progressLearn SET progressLearn.score = 0 WHERE progressLearn.id_user = '$id_user' AND progressLearn.id_lesson = '$final';";
    
    if (mysqli_multi_query($connect, $query)) {
        echo "success";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($connect);
    }
    mysqli_close($connect);
}