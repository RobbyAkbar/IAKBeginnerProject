<?php
/**
 * Created by PhpStorm.
 * User: robby
 * Date: 31/05/20
 * Time: 17:23
 */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require 'con.php';
    getSoal();
}

function getSoal() {
    global $connect;
    $id_user = $_POST["id_user"];
    $id_lesson = $_POST["id_lesson"];
    $query = "SELECT quiz.id_quiz, quiz.question as soal_pg, quiz.answer1, quiz.answer2, quiz.answer3, quiz.answer4, quiz.answer_key, guess.id_guess, guess.question as soal_sql, guess.correct_answer, guess.score_weight, progressQuiz.answer as jawaban FROM quiz INNER JOIN guess ON quiz.id_lesson = guess.id_lesson LEFT JOIN progressQuiz ON quiz.id_quiz = progressQuiz.id_quiz AND progressQuiz.id_user = '$id_user' WHERE quiz.id_lesson = '$id_lesson';";
    $result = mysqli_query($connect,$query);

    if(mysqli_num_rows($result)>0){
        $arr = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $temp = array("id_quiz" => $row["id_quiz"], "soal_pg" => $row["soal_pg"], "answer1" => $row["answer1"], "answer2" => $row["answer2"], "answer3" => $row["answer3"], "answer4" => $row["answer4"], "answer_key" => $row["answer_key"], "id_guess" => $row["id_guess"], "soal_sql" => $row["soal_sql"], "correct_answer" => $row["correct_answer"], "score_weight" => $row["score_weight"], "jawaban" => $row["jawaban"]);
            array_push($arr, $temp);
        }
        $data = json_encode($arr);
        echo "$data";
    } else {
        echo "failure";
    }

    mysqli_close($connect);
}