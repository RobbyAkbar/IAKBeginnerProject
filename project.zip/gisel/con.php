<?php
/**
 * Created by PhpStorm.
 * User: robby
 * Date: 10/03/19
 * Time: 17:16
 */

define('hostname', 'localhost');
define('user', 'u7050039_gisel');
define('password', '@tts123GiselApp');
define('databaseName', 'u7050039_gisel');

$connect = mysqli_connect(hostname, user, password, databaseName) or die('Unable to Connect');
