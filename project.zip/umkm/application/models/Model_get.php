<?php

class Model_get extends CI_Model {
	public function kecamatan(){
		return $this->db->get('districts')->result();
	}
	public function kelurahan(){
		return $this->db
			->where('district_id', $this->input->post('id_kec'))
			->get('villages')
			->result();
	}
	public function kategori(){
		return $this->db->get('kategori')->result();
	}
}
