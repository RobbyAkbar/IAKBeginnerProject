<?php

class Model_auth extends CI_Model {
	public function cek_login($code){
		$username = set_value('username');
		$password = set_value('password');
		$result = "";
		if ($code==1){
			$result = $this->db
				->where('username', $username)
				->limit(1)
				->get('admin');
		} else if ($code==2){
			$result = $this->db
				->select('pemilik.idPemilik, pemilik.namaPemilik, pemilik.password, toko.idToko')
				->join('toko', 'pemilik.idPemilik = toko.idPemilik', 'left')
				->where('emailPemilik', $username)
				->limit(1)
				->get('pemilik');
		}
		if ($result->num_rows() > 0){
			if (password_verify($password, $result->row()->password)) return $result->row();
			else return array();
		}
		else return array();
	}
}
