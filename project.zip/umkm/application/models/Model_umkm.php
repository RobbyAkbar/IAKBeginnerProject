<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Model_umkm extends CI_Model {
	private $_table = "toko";
	private $_tableJoin = "kategori";
	public $namaToko, $alamatToko, $linkToko, $fotoToko, $lat, $lng;
	public $idKecamatan, $idKelurahan, $idKategori, $idPemilik;

	public function rules() {
		return array(
			array('field' => 'namaToko', 'label' => 'Nama Usaha', 'rules' => 'required', 'errors' => array('required' => 'Nama usaha wajib diisi!')),
			array('field' => 'alamatToko', 'label' => 'Alamat Usaha', 'rules' => 'required', 'errors' => array('required' => 'Alamat usaha wajib diisi!')),
			array('field' => 'idKecamatan', 'label' => 'Kecamatan', 'rules' => 'required', 'errors' => array('required' => 'Harap pilih kecamatan!')),
			array('field' => 'idKelurahan', 'label' => 'Kelurahan', 'rules' => 'required', 'errors' => array('required' => 'Harap pilih kelurahan!')),
			array('field' => 'idKategori', 'label' => 'Kategori', 'rules' => 'required', 'errors' => array('required' => 'Harap pilih kategori!')),
			array('field' => 'longitude', 'label' => 'Longitude', 'rules' => 'required', 'errors' => array('required' => 'Harap pilih Lokasi!'))
		);
	}

	public function getVerified($limit, $start) {
		return $this->db->join($this->_tableJoin,
			'toko.idKategori = kategori.id', 'inner')
			->where('statusToko', 'verified')
			->get($this->_table, $limit, $start)->result();
	}

	public function getAll() {
		return $this->db->join($this->_tableJoin,
			'toko.idKategori = kategori.id', 'inner')
			->get($this->_table)->result();
	}

	public function getById(){
		return $this->db->where('idPemilik', $this->session->userdata('idPemilik'))
			->get($this->_table)->row();
	}

	public function getUMKMById($id){
		$result = $this->db->select('toko.namaToko, toko.alamatToko, toko.linkToko, toko.fotoToko, toko.statusToko, toko.lat, toko.lng,
		kategori.name AS namaKategori, pemilik.namaPemilik, pemilik.noHp, districts.name AS kecamatan, villages.name AS kelurahan')
			->join($this->_tableJoin, 'toko.idKategori = kategori.id', 'inner')
			->join('pemilik', 'toko.idPemilik = pemilik.idPemilik', 'inner')
			->join('districts', 'toko.idKecamatan = districts.id', 'inner')
			->join('villages', 'toko.idKelurahan = villages.id', 'inner')
			->where('idToko', $id)
			->get($this->_table);
		if ($result->num_rows() > 0) return $result->row();
		else return array();
	}

	public function search($keyword){
		return $this->db->select('toko.idToko, toko.namaToko, toko.alamatToko, toko.fotoToko, kategori.name')
			->join('produk', 'toko.idToko = produk.idToko', 'inner')
			->join('districts', 'toko.idKecamatan = districts.id', 'inner')
			->join('villages', 'toko.idKelurahan = villages.id', 'inner')
			->join($this->_tableJoin, 'toko.idKategori = kategori.id', 'inner')
			->like('districts.name', $keyword, 'both')
			->or_like('villages.name', $keyword, 'both')
			->or_like('produk.namaProduk', $keyword, 'both')
			->or_like('toko.namaToko', $keyword, 'both')
			->group_by("idToko")
			->get($this->_table)->result();
	}

	public function getByCategory($category, $limit, $start){
		return $this->db->join($this->_tableJoin,
			'toko.idKategori = kategori.id', 'inner')
			->where('statusToko', 'verified')
			->where('idKategori', $category)
			->get($this->_table, $limit, $start)->result();
	}

	public function countCategory(){
		return $this->db->select('kategori.name, COUNT(toko.idKategori) AS jumlah')
			->join('(SELECT * FROM toko WHERE toko.statusToko = "verified") toko', 'kategori.id = toko.idKategori', 'left')
			->group_by('kategori.name')
			->get('kategori')->result();
	}

	public function countDistrict(){
		return $this->db->select('districts.name, COUNT(toko.idKecamatan) AS jumlah')
			->join('(SELECT * FROM toko WHERE toko.statusToko = "verified") toko', 'districts.id = toko.idKecamatan', 'left')
			->group_by('districts.name')
			->get('districts')->result();
	}

	public function save() {
		$post = $this->input->post();
		$id = $this->session->userdata('idPemilik');
		$this->namaToko = $post["namaToko"];
		$this->alamatToko = $post["alamatToko"];
		$this->linkToko = $post["linkToko"];
		$this->idKecamatan = $post["idKecamatan"];
		$this->idKelurahan = $post["idKelurahan"];
		$this->idKategori = $post["idKategori"];
		$this->lat = $post["latitude"];
		$this->lng = $post["longitude"];
		$this->idPemilik = $id;
		$this->fotoToko = $this->_uploadImage();
		$this->db->insert($this->_table, $this);
	}

	public function editStatus() {
		$post = $this->input->post();
		$statusToko = $post["statusToko"];
		$idToko = $post["idToko"];
		$this->db->set('statusToko', $statusToko)
			->where('idToko', $idToko)
			->update($this->_table);
		return $statusToko;
	}

	private function _uploadImage() {
		$config['upload_path']          = './uploads/foto_toko/';
		$config['allowed_types']        = 'jpg|jpeg||png';
		$config['file_name']            = $this->namaToko;
		$config['overwrite']			= true;
		//$config['max_size']             = 1024;
		$this->load->library('upload', $config);
		if ($this->upload->do_upload('fotoToko')) {
			return $this->upload->data("file_name");
		}
		return "images.svg";
	}
}
