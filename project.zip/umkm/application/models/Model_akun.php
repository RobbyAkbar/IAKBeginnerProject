<?php

class Model_akun extends CI_Model {
	private $_table = "pemilik";
	public  $namaPemilik, $noHp, $emailPemilik, $password,
		$alamatPemilik, $nikPemilik, $fotoKtp;

	public function rules() {
		return array(
			array('field' => 'namaPemilik', 'label' => 'Nama Pemilik', 'rules' => 'required', 'errors' => array('required' => 'Nama wajib diisi!')),
			array('field' => 'noHp', 'label' => 'No Hp', 'rules' => 'required|numeric', 'errors' => array('required' => 'No Hp wajib diisi!', 'numeric' => 'Hanya diisi dengan angka saja!')),
			array('field' => 'emailPemilik', 'label' => 'Email Pemilik', 'rules' => 'required', 'errors' => array('required' => 'Email wajib diisi!')),
			array('field' => 'password1', 'label' => 'Password', 'rules' => 'required|matches[password2]', 'errors' => array('required' => 'Password wajib diisi!', 'matches' => 'Password tidak cocok!')),
			array('field' => 'password2', 'label' => 'Password', 'rules' => 'required|matches[password1]', 'errors' => array('required' => 'Password wajib diisi!')),
			array('field' => 'alamatPemilik', 'label' => 'Alamat Pemilik', 'rules' => 'required', 'errors' => array('required' => 'Alamat wajib diisi!')),
			array('field' => 'nikPemilik', 'label' => 'NIK Pemilik', 'rules' => 'required|numeric', 'errors' => array('required' => 'NIK wajib diisi!', 'numeric' => 'Hanya diisi dengan angka saja!'))
		);
	}

	public function save() {
		$post = $this->input->post();
		$this->namaPemilik = $post["namaPemilik"];
		$this->emailPemilik = $post["emailPemilik"];
		$this->password = password_hash($post["password1"], PASSWORD_DEFAULT);
		$this->noHp = $post["noHp"];
		$this->alamatPemilik = $post["alamatPemilik"];
		$this->nikPemilik = $post["nikPemilik"];
		$this->fotoKtp = $this->_uploadImage();
		$this->db->insert($this->_table, $this);
	}

	private function _uploadImage() {
		$config['upload_path']          = './uploads/foto_ktp/';
		$config['allowed_types']        = 'jpg|jpeg||png';
		$config['file_name']            = $this->namaPemilik.$this->nikPemilik;
		$config['overwrite']			= true;
		//$config['max_size']             = 1024;
		$this->load->library('upload', $config);
		if ($this->upload->do_upload('fotoKtp')) {
			return $this->upload->data("file_name");
		}
		return "images.svg";
	}
}
