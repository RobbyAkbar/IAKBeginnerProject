<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Model_produk extends CI_Model {
	private $_table = "produk";
	public  $idProduk, $namaProduk, $hargaProduk, $fotoProduk, $deskripsiProduk, $idToko;

	public function rules() {
		return array(
			array('field' => 'namaProduk', 'label' => 'Nama Produk', 'rules' => 'required', 'errors' => array('required' => 'Nama produk wajib diisi!')),
			array('field' => 'hargaProduk', 'label' => 'Harga Produk', 'rules' => 'required|numeric', 'errors' => array('required' => 'Harga produk wajib diisi!', 'numeric' => 'Harap diisi dengan angka saja')),
			array('field' => 'deskripsiProduk', 'label' => 'Deskripsi Produk', 'rules' => 'required', 'errors' => array('required' => 'Deskripsi produk wajib diisi!'))
		);
	}

	public function getAll() {
		return $this->db->get($this->_table)->result();
	}

	public function getAllByToko($id) {
		return $this->db->where('idToko', $id)
			->get($this->_table)->result();
	}

	public function getById($id) {
		return $this->db->where('idProduk', $id)
			->get($this->_table)->row();
	}

	public function save() {
		$post = $this->input->post();
		$id = $this->session->userdata('idToko');
		$this->idProduk = uniqid();
		$this->namaProduk = $post["namaProduk"];
		$this->hargaProduk = $post["hargaProduk"];
		$this->deskripsiProduk = $post["deskripsiProduk"];
		$this->idToko = $id;
		$this->fotoProduk = $this->_uploadImage($this->namaProduk,$this->idToko);
		$this->db->insert($this->_table, $this);
	}

	private function _uploadImage($namaProduk, $idToko) {
		$config['upload_path']          = './uploads/foto_produk/';
		$config['allowed_types']        = 'jpg|jpeg||png';
		$config['file_name']            = $namaProduk.$idToko;
		$config['overwrite']			= true;
		//$config['max_size']             = 1024;
		$this->load->library('upload', $config);
		if ($this->upload->do_upload('fotoProduk')) {
			return $this->upload->data("file_name");
		}
		return "images.svg";
	}

	private function _deleteImage($id) {
		$product = $this->getById($id);
		if ($product->fotoProduk != "images.svg") {
			$filename = explode(".", $product->fotoProduk)[0];
			return array_map('unlink', glob(FCPATH."uploads/foto_produk/$filename.*"));
		} else return array();
	}

	public function update() {
		$post = $this->input->post();
		if (!empty($_FILES["fotoProduk"]["name"])) $image = $this->_uploadImage(explode(".", $post["old_image"])[0],"");
		else $image = $post["old_image"];
		$data = array(
			'namaProduk' => $post["namaProduk"],
			'hargaProduk' => $post["hargaProduk"],
			'deskripsiProduk' => $post["deskripsiProduk"],
			'fotoProduk' => $image
		);
		$this->db->update($this->_table, $data, array('idProduk' => $post['idProduk']));
	}

	public function delete($id) {
		$this->_deleteImage($id);
		return $this->db->delete($this->_table, array('idProduk' => $id));
	}
}
