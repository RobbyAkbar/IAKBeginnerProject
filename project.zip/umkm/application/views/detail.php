<!-- Begin Page Content -->
<div class="container-fluid">
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard') ?>">Beranda</a></li>
			<li class="breadcrumb-item"><a href="<?php
				$type = "";
					switch ($toko->namaKategori){
						case "Agribisnis": $type = "agribisnis"; break;
						case "Makanan": $type = "makanan"; break;
						case "Minuman": $type = "minuman"; break;
						case "Makanan & Minuman": $type = "mami"; break;
						case "Fashion": $type = "fashion"; break;
						case "Craft": $type = "craft"; break;
						case "Aksesoris": $type = "aksesoris"; break;
						case "Bordir": $type = "bordir"; break;
						case "Jasa Salon": $type = "salon"; break;
						case "Batik": $type = "batik"; break;
						case "Mebel": $type = "mebel"; break;
						case "Konveksi": $type = "konveksi"; break;
						case "Kuliner": $type = "kuliner"; break;
						case "Obat-Obatan": $type = "obat"; break;
						case "Industri": $type = "industri"; break;
						case "Dekorasi": $type = "dekorasi"; break;
						case "Garment": $type = "garment"; break;
						case "Toko atau Retail": $type = "retail"; break;
						default: $type = ""; break;
					}
				echo base_url('dashboard/').$type ?>"><?php echo $toko->namaKategori ?></a></li>
			<li class="breadcrumb-item active" aria-current="page"><?php echo $toko->namaToko." " ?><?php
				if ($toko->statusToko == "unverified") echo "<span class=\"badge badge-danger\">Belum diverifikasi</span>";
				else if ($toko->statusToko == "verified") echo "<span class=\"badge badge-success\">Terverifikasi</span>"; ?></li>
		</ol>
	</nav>
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Detail UMKM</h6>
		</div>
		<div class="card-body">
			<div class="row">
				<div class="col-md-4 text-center mb-3">
					<img src="<?php echo base_url().'/uploads/foto_toko/'.$toko->fotoToko ?>" class="img-thumbnail" alt="..." style="object-fit: cover; object-position: center; height: 300px; width: 500px;">
				</div>
				<div class="col-md-8">
					<table class="table">
						<tr>
							<td><strong>Nama UMKM</strong></td>
							<td><?php echo $toko->namaToko ?></td>
						</tr>
						<tr>
							<td><strong>Nama Pemilik</strong></td>
							<td><?php echo $toko->namaPemilik ?></td>
						</tr>
						<tr>
							<td><strong>Kontak</strong></td>
							<td><?php echo $toko->noHp ?></td>
						</tr>
						<tr>
							<td><strong>Alamat UMKM</strong></td>
							<td><?php echo $toko->alamatToko ?></td>
						</tr>
						<tr>
							<td></td>
							<td><?php echo "Kecamatan ".$toko->kecamatan.", Kelurahan ".$toko->kelurahan."." ?></td>
						</tr>
						<tr>
							<td><strong>Link Website</strong></td>
							<td><?php if ($toko->linkToko!=null) { ?>
									<a href="<?php echo $toko->linkToko ?>"><?php echo $toko->linkToko ?></a>
								<?php } else { echo "-"; } ?></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<div id="map" style="height: 300px;">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row text-center ml-5 mr-5">
		<?php foreach ($produk as $item) :?>
			<div class="card m-3" style="width: 16rem;">
				<img src="<?php echo base_url().'/uploads/foto_produk/'.$item->fotoProduk ?>" class="img-thumbnail" alt="..." style="object-fit: cover; object-position: center; height: 200px;">
				<div class="card-body">
					<h5 class="card-title"><?php echo $item->namaProduk ?></h5>
					<small><?php echo $item->deskripsiProduk ?></small><br>
					<span class="badge badge-pill badge-success mb-3"><?php echo "Rp.".number_format($item->hargaProduk,2,",",".") ?></span>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</div>

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy; UMKM Purwakarta 2019</span>
		</div>
	</div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Siap untuk keluar?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Pilih "Keluar" di bawah ini, jika Anda ingin mengakhiri sesi Anda saat ini.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
				<a class="btn btn-primary" href="<?php echo base_url('auth/logout') ?>">Keluar</a>
			</div>
		</div>
	</div>
</div>
<script>
    function initialize() {
        const propertiPeta = {
            center: new google.maps.LatLng(<?php echo $toko->lat?>, <?php echo $toko->lng?>),
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            streetViewControl: false,
            mapTypeControl: false
        };
        const peta = new google.maps.Map(document.getElementById("map"), propertiPeta);
        const marker = new google.maps.Marker({
            position: new google.maps.LatLng(<?php echo $toko->lat?>, <?php echo $toko->lng?>),
            map: peta,
            animation: google.maps.Animation.BOUNCE
        });
    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?callback=initialize&key=AIzaSyDpsSPtYu3jdwpptEvKjIf89aOph2wdYEg" async defer></script>
