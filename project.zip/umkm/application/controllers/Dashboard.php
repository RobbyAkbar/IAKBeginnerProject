<?php

class Dashboard extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->library('pagination');
		$this->load->model("model_umkm");
		$this->load->model("model_produk");
	}

	public function index(){
		$config['base_url'] = site_url('dashboard/index');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getVerified($config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$data['kategori'] = $this->model_umkm->countCategory();
		$data['kecamatan'] = $this->model_umkm->countDistrict();
		$mData['menu'] = "Dashboard";
		$data['scroll'] = 0;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function agribisnis(){
		$config['base_url'] = site_url('dashboard/agribisnis');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k01')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k01", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Agribisnis";
		$data['scroll'] = 0;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function makanan(){
		$config['base_url'] = site_url('dashboard/makanan');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k02')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k02", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Makanan";
		$data['scroll'] = 0;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function minuman(){
		$config['base_url'] = site_url('dashboard/minuman');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k03')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k03", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Minuman";
		$data['scroll'] = 0;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function mami(){
		$config['base_url'] = site_url('dashboard/mami');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k04')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k04", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Makanan & Minuman";
		$data['scroll'] = 30;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function fashion(){
		$config['base_url'] = site_url('dashboard/fashion');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k05')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k05", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Fashion";
		$data['scroll'] = 86;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function craft(){
		$config['base_url'] = site_url('dashboard/craft');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k06')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k06", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Craft";
		$data['scroll'] = 142;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function aksesoris(){
		$config['base_url'] = site_url('dashboard/aksesoris');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k07')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k07", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Aksesoris";
		$data['scroll'] = 198;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function bordir(){
		$config['base_url'] = site_url('dashboard/bordir');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k08')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k08", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Bordir";
		$data['scroll'] = 254;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function salon(){
		$config['base_url'] = site_url('dashboard/salon');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k09')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k09", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Jasa Salon";
		$data['scroll'] = 310;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function batik(){
		$config['base_url'] = site_url('dashboard/batik');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k10')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k10", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Batik";
		$data['scroll'] = 366;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function mebel(){
		$config['base_url'] = site_url('dashboard/mebel');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k11')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k11", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Mebel";
		$data['scroll'] = 422;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function konveksi(){
		$config['base_url'] = site_url('dashboard/konveksi');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k12')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k12", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Konveksi";
		$data['scroll'] = 478;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function kuliner(){
		$config['base_url'] = site_url('dashboard/kuliner');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k13')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k13", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Kuliner";
		$data['scroll'] = 534;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function obat(){
		$config['base_url'] = site_url('dashboard/obat');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k14')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k14", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Obat-Obatan";
		$data['scroll'] = 590;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function industri(){
		$config['base_url'] = site_url('dashboard/industri');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k15')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k15", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Industri";
		$data['scroll'] = 646;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function dekorasi(){
		$config['base_url'] = site_url('dashboard/dekorasi');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k16')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k16", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Dekorasi";
		$data['scroll'] = 674;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function garment(){
		$config['base_url'] = site_url('dashboard/garment');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k17')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k17", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Garment";
		$data['scroll'] = 674;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function retail(){
		$config['base_url'] = site_url('dashboard/retail');
		$config['total_rows'] = $this->db->where('statusToko', 'verified')->where('idKategori', 'k18')->from('toko')->count_all_results();
		$config['per_page'] = 10;
		$choice = $config["total_rows"] / $config["per_page"];
		$config["num_links"] = floor($choice);

		$this->pagination->initialize($config);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['toko'] = $this->model_umkm->getByCategory("k18", $config["per_page"], $data['page']);
		$data['pagination'] = $this->pagination->create_links();

		$mData['menu'] = "Toko atau Retail";
		$data['scroll'] = 674;
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function umkm($id = null){
		if (!isset($id)) redirect('dashboard');
		$toko = $this->model_umkm->getUMKMById($id);
		if ($toko) $data['toko'] = $toko;
		else {
			$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Upss!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Link yang anda kunjungi salah, tidak dapat ditemukan.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');
			redirect('dashboard');
		}
		$data['produk'] = $this->model_produk->getAllByToko($id);
		$mData['menu'] = "Dashboard";
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('detail', $data);
		$this->load->view('templates/footer');
	}

	public function search(){
		$keyword = $this->input->get("keyword");
		$data['hasil'] = $this->model_umkm->search($keyword);
		$mData['menu'] = "Dashboard";
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('search', $data);
		$this->load->view('templates/footer');
	}

}
