<?php

class Daftar extends CI_Controller {
	public function kecamatan(){
		$data=$this->model_get->kecamatan();
		echo json_encode($data);
	}
	public function kelurahan(){
		$data=$this->model_get->kelurahan();
		echo json_encode($data);
	}
	public function kategori(){
		$data=$this->model_get->kategori();
		echo json_encode($data);
	}
}
