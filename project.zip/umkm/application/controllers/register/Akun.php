<?php

class Akun extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model("model_akun");
		$this->load->library('form_validation');
	}
	public function index(){
		if ($this->session->userdata('username') != null) {
			$this->session->set_flashdata('pesan', '
				<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  					<div class="modal-dialog" role="document">
    					<div class="modal-content">
      						<div class="modal-header">
        						<h5 class="modal-title">Upss!</h5>
        						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          							<span aria-hidden="true">×</span>
        						</button>
      						</div>
      						<div class="modal-body">
        						<p>Anda telah masuk, mohon keluar dari akun terlebih dahulu.</p>
      						</div>
      						<div class="modal-footer">
        						<button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      						</div>
    					</div>
  					</div>
				</div>');
			redirect('dashboard');
		} else {
			$akun = $this->model_akun;
			$validation = $this->form_validation;
			$validation->set_rules($akun->rules());
			if ($validation->run()) {
				$akun->save();
				$this->session->set_flashdata('pesan', '
					<div class="alert alert-success alert-dismissible fade show" role="alert">
  						<strong>Berhasil membuat akun!</strong> Silahkan masuk.
  						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    						<span aria-hidden="true">&times;</span>
  						</button>
					</div>');
				redirect('auth/login');
			} else {
				$this->load->view('templates/header');
				$this->load->view('register_akun');
				$this->load->view('templates/footer');
			}
		}
	}
}
