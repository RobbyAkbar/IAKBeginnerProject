<?php

class Umkm extends CI_Controller {
	public function __construct() {
		parent::__construct();
		if ($this->session->userdata('username') == null) {
			$this->session->set_flashdata('pesan', '
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
  						<strong>Upss!</strong> Masuk terlebih dahulu.
  						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    						<span aria-hidden="true">&times;</span>
  						</button>
					</div>');
			redirect('auth/login');
		} else {
			if ($this->session->userdata('hak_akses')==777){
				$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Upss!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Admin tidak bisa daftar UMKM. Masuklah sebagai pengguna!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');
				redirect('admin/dashboard_admin');
			}
			if ($this->session->userdata('idToko')!=null){
				$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Upss!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Untuk saat ini anda hanya boleh mendaftarkan satu UMKM!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');
				redirect('dashboard');
			}
		}
		$this->load->model("model_umkm");
		$this->load->library('form_validation');
	}
	public function index(){
		$umkm = $this->model_umkm;
		$validation = $this->form_validation;
		$validation->set_rules($umkm->rules());
		if ($validation->run()) {
			$umkm->save();
			$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Selamat!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>UMKM anda telah didaftarkan, mohon tunggu sampai diverfikasi!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');
			$check = $this->model_umkm->getById();
			$this->session->set_userdata(array('idToko' => $check->idToko));
			redirect('dashboard');
		} else {
			$this->load->view('templates/header');
			$this->load->view('register_umkm');
			$this->load->view('templates/footer');
		}
	}
}
