<?php

class Dashboard_admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		if ($this->session->userdata('username')==null){
			$this->session->set_flashdata('pesan', '
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
  						<strong>Upss!</strong> Masuk terlebih dahulu.
  						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    						<span aria-hidden="true">&times;</span>
  						</button>
					</div>');
			redirect('admin/login');
		} else {
			if ($this->session->userdata('hak_akses')!=777){
				$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Upss!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Anda tidak memiliki hak akses.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');
				redirect('dashboard');
			}
		}
		$this->load->model("model_umkm");
	}

	public function index() {
		$data['toko'] = $this->model_umkm->getAll();
		$this->load->view('templates_admin/header');
		$this->load->view('templates_admin/sidebar');
		$this->load->view('admin/dashboard', $data);
		$this->load->view('templates_admin/footer');
	}

}
