<?php

class MyUMKM extends CI_Controller {
	public function __construct() {
		parent::__construct();
		if ($this->session->userdata('username') == null) {
			$this->session->set_flashdata('pesan', '
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
  						<strong>Upss!</strong> Masuk terlebih dahulu.
  						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    						<span aria-hidden="true">&times;</span>
  						</button>
					</div>');
			redirect('auth/login');
		} else {
			if ($this->session->userdata('hak_akses')==777){
				$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Upss!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Admin tidak bisa mempunyai UMKM. Masuklah sebagai pengguna!</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');	redirect('admin/dashboard_admin');
			}
			if ($this->session->userdata('idToko')==null){
				$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Upss!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Anda belum mendaftarkan UMKM! Daftar terlebih dahulu untuk melihat halaman ini.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');
				redirect('dashboard');
			}
		}
		$this->load->model("model_umkm");
		$this->load->model("model_produk");
	}

	public function index(){
		$check = $this->model_umkm->getById();
		$data['myToko'] = $check;
		$mData['menu'] = "myUMKM";
		if ($check->statusToko == 'verified'){
			$data['myProduk'] = $this->model_produk->getAllByToko($check->idToko);
		}
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar', $mData);
		$this->load->view('my_umkm', $data);
		$this->load->view('templates/footer');
	}
}
