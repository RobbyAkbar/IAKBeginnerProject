<?php

class Auth extends CI_Controller {
	public function login(){
		if ($this->session->userdata('username')!=null){
			$this->session->set_flashdata('pesan', '
<div class="modal fade" id="autoModal" tabindex="-1" role="dialog" aria-labelledby="autoModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Upss!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Anda telah masuk, mohon keluar dari akun terlebih dahulu.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Oke</button>
      </div>
    </div>
  </div>
</div>');
			redirect('dashboard');
		} else {
			$this->form_validation->set_rules('username', 'Username', 'required', ['required' => 'Email wajib diisi!']);
			$this->form_validation->set_rules('password', 'Password', 'required', ['required' => 'Password wajib diisi!']);
			if ($this->form_validation->run() == false){
				$this->load->view('templates/header');
				$this->load->view('form_login');
				$this->load->view('templates/footer');
			} else {
				$auth = $this->model_auth->cek_login(2);
				if ($auth == false){
					$this->session->set_flashdata('pesan', '
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
  						<strong>Upss!</strong> Email atau Password anda salah.
  						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    						<span aria-hidden="true">&times;</span>
  						</button>
					</div>');
					redirect('auth/login');
				} else {
					$data = array(
						'username' => $auth->namaPemilik,
						'idPemilik' => $auth->idPemilik,
						'idToko' => $auth->idToko
					);
					$this->session->set_userdata($data);
					redirect('dashboard');
				}
			}
		}
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect('auth/login');
	}
	public function out(){
		$this->session->sess_destroy();
		redirect('admin/login');
	}
}
