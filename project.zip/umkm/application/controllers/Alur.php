<?php

class Alur extends CI_Controller {
	public function index(){
		$this->load->view('alur_pendaftaran');
	}
}
