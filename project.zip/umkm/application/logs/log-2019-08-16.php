<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-16 17:00:56 --> Config Class Initialized
INFO - 2019-08-16 17:00:56 --> Hooks Class Initialized
DEBUG - 2019-08-16 17:00:56 --> UTF-8 Support Enabled
INFO - 2019-08-16 17:00:56 --> Utf8 Class Initialized
INFO - 2019-08-16 17:00:56 --> URI Class Initialized
INFO - 2019-08-16 17:00:56 --> Router Class Initialized
INFO - 2019-08-16 17:00:56 --> Output Class Initialized
INFO - 2019-08-16 17:00:56 --> Security Class Initialized
DEBUG - 2019-08-16 17:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-16 17:00:56 --> Input Class Initialized
INFO - 2019-08-16 17:00:56 --> Language Class Initialized
INFO - 2019-08-16 17:00:56 --> Loader Class Initialized
INFO - 2019-08-16 17:00:56 --> Helper loaded: url_helper
INFO - 2019-08-16 17:00:56 --> Database Driver Class Initialized
DEBUG - 2019-08-16 17:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-16 17:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-16 17:00:56 --> Helper loaded: form_helper
INFO - 2019-08-16 17:00:56 --> Form Validation Class Initialized
INFO - 2019-08-16 17:00:56 --> Model "Model_auth" initialized
INFO - 2019-08-16 17:00:56 --> Model "Model_get" initialized
INFO - 2019-08-16 17:00:56 --> Controller Class Initialized
INFO - 2019-08-16 17:00:56 --> Model "Model_umkm" initialized
ERROR - 2019-08-16 17:00:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/umkm/system/core/Log.php 180
INFO - 2019-08-16 17:00:56 --> File loaded: /var/www/html/umkm/application/views/templates/header.php
INFO - 2019-08-16 17:00:56 --> File loaded: /var/www/html/umkm/application/views/templates/sidebar.php
INFO - 2019-08-16 17:00:56 --> File loaded: /var/www/html/umkm/application/views/my_umkm.php
INFO - 2019-08-16 17:00:56 --> File loaded: /var/www/html/umkm/application/views/templates/footer.php
INFO - 2019-08-16 17:00:56 --> Final output sent to browser
DEBUG - 2019-08-16 17:00:56 --> Total execution time: 0.0227
INFO - 2019-08-16 17:01:57 --> Config Class Initialized
INFO - 2019-08-16 17:01:57 --> Hooks Class Initialized
DEBUG - 2019-08-16 17:01:57 --> UTF-8 Support Enabled
INFO - 2019-08-16 17:01:57 --> Utf8 Class Initialized
INFO - 2019-08-16 17:01:57 --> URI Class Initialized
INFO - 2019-08-16 17:01:57 --> Router Class Initialized
INFO - 2019-08-16 17:01:57 --> Output Class Initialized
INFO - 2019-08-16 17:01:57 --> Security Class Initialized
DEBUG - 2019-08-16 17:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-16 17:01:57 --> Input Class Initialized
INFO - 2019-08-16 17:01:57 --> Language Class Initialized
INFO - 2019-08-16 17:01:57 --> Loader Class Initialized
INFO - 2019-08-16 17:01:57 --> Helper loaded: url_helper
INFO - 2019-08-16 17:01:57 --> Database Driver Class Initialized
DEBUG - 2019-08-16 17:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-16 17:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-16 17:01:57 --> Helper loaded: form_helper
INFO - 2019-08-16 17:01:57 --> Form Validation Class Initialized
INFO - 2019-08-16 17:01:57 --> Model "Model_auth" initialized
INFO - 2019-08-16 17:01:57 --> Model "Model_get" initialized
INFO - 2019-08-16 17:01:57 --> Controller Class Initialized
INFO - 2019-08-16 17:01:57 --> Model "Model_umkm" initialized
INFO - 2019-08-16 17:01:57 --> test
INFO - 2019-08-16 17:01:57 --> File loaded: /var/www/html/umkm/application/views/templates/header.php
INFO - 2019-08-16 17:01:57 --> File loaded: /var/www/html/umkm/application/views/templates/sidebar.php
INFO - 2019-08-16 17:01:57 --> File loaded: /var/www/html/umkm/application/views/my_umkm.php
INFO - 2019-08-16 17:01:57 --> File loaded: /var/www/html/umkm/application/views/templates/footer.php
INFO - 2019-08-16 17:01:57 --> Final output sent to browser
DEBUG - 2019-08-16 17:01:57 --> Total execution time: 0.0291
INFO - 2019-08-16 17:02:00 --> Config Class Initialized
INFO - 2019-08-16 17:02:00 --> Hooks Class Initialized
DEBUG - 2019-08-16 17:02:00 --> UTF-8 Support Enabled
INFO - 2019-08-16 17:02:00 --> Utf8 Class Initialized
INFO - 2019-08-16 17:02:00 --> URI Class Initialized
INFO - 2019-08-16 17:02:00 --> Router Class Initialized
INFO - 2019-08-16 17:02:00 --> Output Class Initialized
INFO - 2019-08-16 17:02:00 --> Security Class Initialized
DEBUG - 2019-08-16 17:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-16 17:02:00 --> Input Class Initialized
INFO - 2019-08-16 17:02:00 --> Language Class Initialized
INFO - 2019-08-16 17:02:00 --> Loader Class Initialized
INFO - 2019-08-16 17:02:00 --> Helper loaded: url_helper
INFO - 2019-08-16 17:02:00 --> Database Driver Class Initialized
DEBUG - 2019-08-16 17:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-16 17:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-16 17:02:00 --> Helper loaded: form_helper
INFO - 2019-08-16 17:02:00 --> Form Validation Class Initialized
INFO - 2019-08-16 17:02:00 --> Model "Model_auth" initialized
INFO - 2019-08-16 17:02:00 --> Model "Model_get" initialized
INFO - 2019-08-16 17:02:00 --> Controller Class Initialized
INFO - 2019-08-16 17:02:00 --> Model "Model_umkm" initialized
INFO - 2019-08-16 17:02:00 --> test
INFO - 2019-08-16 17:02:00 --> File loaded: /var/www/html/umkm/application/views/templates/header.php
INFO - 2019-08-16 17:02:00 --> File loaded: /var/www/html/umkm/application/views/templates/sidebar.php
INFO - 2019-08-16 17:02:00 --> File loaded: /var/www/html/umkm/application/views/my_umkm.php
INFO - 2019-08-16 17:02:00 --> File loaded: /var/www/html/umkm/application/views/templates/footer.php
INFO - 2019-08-16 17:02:00 --> Final output sent to browser
DEBUG - 2019-08-16 17:02:00 --> Total execution time: 0.0221
INFO - 2019-08-16 17:02:01 --> Config Class Initialized
INFO - 2019-08-16 17:02:01 --> Hooks Class Initialized
DEBUG - 2019-08-16 17:02:01 --> UTF-8 Support Enabled
INFO - 2019-08-16 17:02:01 --> Utf8 Class Initialized
INFO - 2019-08-16 17:02:01 --> URI Class Initialized
INFO - 2019-08-16 17:02:01 --> Router Class Initialized
INFO - 2019-08-16 17:02:01 --> Output Class Initialized
INFO - 2019-08-16 17:02:01 --> Security Class Initialized
DEBUG - 2019-08-16 17:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-16 17:02:01 --> Input Class Initialized
INFO - 2019-08-16 17:02:01 --> Language Class Initialized
INFO - 2019-08-16 17:02:01 --> Loader Class Initialized
INFO - 2019-08-16 17:02:01 --> Helper loaded: url_helper
INFO - 2019-08-16 17:02:01 --> Database Driver Class Initialized
DEBUG - 2019-08-16 17:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-16 17:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-16 17:02:01 --> Helper loaded: form_helper
INFO - 2019-08-16 17:02:01 --> Form Validation Class Initialized
INFO - 2019-08-16 17:02:01 --> Model "Model_auth" initialized
INFO - 2019-08-16 17:02:01 --> Model "Model_get" initialized
INFO - 2019-08-16 17:02:01 --> Controller Class Initialized
INFO - 2019-08-16 17:02:01 --> Model "Model_umkm" initialized
INFO - 2019-08-16 17:02:01 --> test
INFO - 2019-08-16 17:02:01 --> File loaded: /var/www/html/umkm/application/views/templates/header.php
INFO - 2019-08-16 17:02:01 --> File loaded: /var/www/html/umkm/application/views/templates/sidebar.php
INFO - 2019-08-16 17:02:01 --> File loaded: /var/www/html/umkm/application/views/my_umkm.php
INFO - 2019-08-16 17:02:01 --> File loaded: /var/www/html/umkm/application/views/templates/footer.php
INFO - 2019-08-16 17:02:01 --> Final output sent to browser
DEBUG - 2019-08-16 17:02:01 --> Total execution time: 0.0184
INFO - 2019-08-16 17:02:27 --> Config Class Initialized
INFO - 2019-08-16 17:02:27 --> Hooks Class Initialized
DEBUG - 2019-08-16 17:02:27 --> UTF-8 Support Enabled
INFO - 2019-08-16 17:02:27 --> Utf8 Class Initialized
INFO - 2019-08-16 17:02:27 --> URI Class Initialized
INFO - 2019-08-16 17:02:27 --> Router Class Initialized
INFO - 2019-08-16 17:02:27 --> Output Class Initialized
INFO - 2019-08-16 17:02:27 --> Security Class Initialized
DEBUG - 2019-08-16 17:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-16 17:02:27 --> Input Class Initialized
INFO - 2019-08-16 17:02:27 --> Language Class Initialized
INFO - 2019-08-16 17:02:27 --> Loader Class Initialized
INFO - 2019-08-16 17:02:27 --> Helper loaded: url_helper
INFO - 2019-08-16 17:02:27 --> Database Driver Class Initialized
DEBUG - 2019-08-16 17:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-16 17:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-16 17:02:27 --> Helper loaded: form_helper
INFO - 2019-08-16 17:02:27 --> Form Validation Class Initialized
INFO - 2019-08-16 17:02:27 --> Model "Model_auth" initialized
INFO - 2019-08-16 17:02:27 --> Model "Model_get" initialized
INFO - 2019-08-16 17:02:27 --> Controller Class Initialized
INFO - 2019-08-16 17:02:27 --> Model "Model_umkm" initialized
ERROR - 2019-08-16 17:02:27 --> test
INFO - 2019-08-16 17:02:27 --> File loaded: /var/www/html/umkm/application/views/templates/header.php
INFO - 2019-08-16 17:02:27 --> File loaded: /var/www/html/umkm/application/views/templates/sidebar.php
INFO - 2019-08-16 17:02:27 --> File loaded: /var/www/html/umkm/application/views/my_umkm.php
INFO - 2019-08-16 17:02:27 --> File loaded: /var/www/html/umkm/application/views/templates/footer.php
INFO - 2019-08-16 17:02:27 --> Final output sent to browser
DEBUG - 2019-08-16 17:02:27 --> Total execution time: 0.0226
