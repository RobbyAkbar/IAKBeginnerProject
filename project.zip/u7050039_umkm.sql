-- MySQL dump 10.16  Distrib 10.2.31-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u7050039_umkm
-- ------------------------------------------------------
-- Server version	10.2.31-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `u7050039_umkm`
--


--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `idAdmin` char(3) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` int(5) NOT NULL,
  PRIMARY KEY (`idAdmin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`idAdmin`, `username`, `password`, `code`) VALUES ('a01','admin','$2y$10$.KwchhZLJWoKl.EE.njehurc5qtXHLStiXHEjz5MbCxiddcSZ3QSS',777);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `districts` (
  `id` char(7) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts`
--

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` (`id`, `name`) VALUES ('3214010','Jatiluhur'),('3214011','Sukasari'),('3214020','Maniis'),('3214030','Tegal Waru'),('3214040','Plered'),('3214050','Sukatani'),('3214060','Darangdan'),('3214070','Bojong'),('3214080','Wanayasa'),('3214081','Kiarapedes'),('3214090','Pasawahan'),('3214091','Pondok Salam'),('3214100','Purwakarta'),('3214101','Babakancikao'),('3214110','Campaka'),('3214111','Cibatu'),('3214112','Bungursari');
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori` (
  `id` char(3) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori`
--

LOCK TABLES `kategori` WRITE;
/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
INSERT INTO `kategori` (`id`, `name`) VALUES ('k01','Agribisnis'),('k02','Makanan'),('k03','Minuman'),('k04','Makanan & Minuman'),('k05','Fashion'),('k06','Craft'),('k07','Aksesoris'),('k08','Bordir'),('k09','Jasa Salon'),('k10','Batik'),('k11','Mebel'),('k12','Konveksi'),('k13','Kuliner'),('k14','Obat-Obatan'),('k15','Industri'),('k16','Dekorasi'),('k17','Garmen'),('k18','Toko atau Retail');
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pemilik`
--

DROP TABLE IF EXISTS `pemilik`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pemilik` (
  `idPemilik` char(5) NOT NULL,
  `namaPemilik` varchar(120) NOT NULL,
  `emailPemilik` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `noHp` char(15) NOT NULL,
  `alamatPemilik` varchar(150) NOT NULL,
  `nikPemilik` char(16) NOT NULL,
  `fotoKtp` varchar(255) NOT NULL,
  `statusAnggota` enum('nonactive','active') NOT NULL DEFAULT 'active',
  `dtDaftar` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idPemilik`),
  UNIQUE KEY `nikPemilik` (`nikPemilik`),
  UNIQUE KEY `emailPemilik` (`emailPemilik`),
  UNIQUE KEY `noHp` (`noHp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pemilik`
--

LOCK TABLES `pemilik` WRITE;
/*!40000 ALTER TABLE `pemilik` DISABLE KEYS */;
INSERT INTO `pemilik` (`idPemilik`, `namaPemilik`, `emailPemilik`, `password`, `noHp`, `alamatPemilik`, `nikPemilik`, `fotoKtp`, `statusAnggota`, `dtDaftar`) VALUES ('p0001','Uni Asneri','robbyakbar@upi.edu','$2y$10$1eswguAsvmU.DK4VKHu8SOr2ijbz.gaACFBfIKwrCr59bgVXJ/EgW','6285219485295','Jl. Erawati 5 No. 20','32112123131','Uni_Asneri32112123131.jpg','active','2019-08-25 05:48:06'),('p0002','Ibbor','ibbor@gmail.com','$2y$10$DUxq6muquMS3VmuFhlIJ2emNOSQyd/HtaAnOoVg8XbSPGG1ADp.K2','6285312430614','Jl. Mawar No. 200','321222222111','Ibbor321222222111.jpg','active','2019-08-25 06:12:01'),('p0003','Eka','nekaristi@gmail.com','$2y$10$/mH3xrkpb6krt0j7d9oEt.h2WGhASGxKlc4OYFoftKSGw4r5xstum','083866140868','Subang ','1000001111122222','Eka10000011111222222.jpg','active','2019-08-25 07:09:40'),('p0004','My Name Is','696969@69.com','$2y$10$6Qu65LNJyC8z40fa2s9SDu.AAqLd5jHG3WSeLSurAlrDebeO2oPVa','6269696969','Jl.69 kec 69 rt 69 rw 69 no69 ','6969696969','My_Name_Is6969696969.jpeg','active','2019-08-25 19:06:37'),('p0005','coba','coba@gmail.com','$2y$10$crO3h0pLnmfyvIVwBR0DvuEoJWsl9NINJIR1SJdinsyENLfOS3vjC','123','Jl in aja dulu','12344126146','coba12344126146.png','active','2019-08-26 22:45:13'),('p0006','Robby Akbar','robbyakbar0@gmail.com','$2y$10$XT86VxDsB7kp0gn0wwF2hOsIr9VuxFB0VNNFQOgx70DSbF7vU258m','6289666549850','Jl Erawati 5 Blok E4 no. 20','3216072311990005','Robby_Akbar3216072311990005.jpg','active','2019-08-27 07:57:46'),('p0007','SMK 2 ','smk2@gmail.com','$2y$10$9VavM.e99cJ0YX3b02ZCw.r/QiLPoKRLGkgsceD8MMHVrse/rgije','082637272119','Jalan Veteran','321098292392019','SMK_2_321098292392019.jpg','active','2019-09-28 10:58:43'),('p0008','Tefa Wirausaha','fcb.sinaga@gmail.com','$2y$10$0UbPhxiGGVR0LInehrL1GeTqYsk6o3ljZ.YqXMIPxLxUP/.Xroswa','08123940202','Jalan SMK 2 Cikarang barat','32104929320291','Tefa_Wirausaha32104929320291.jpg','active','2019-10-03 10:02:42');
/*!40000 ALTER TABLE `pemilik` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`u7050039`@`localhost`*/ /*!50003 TRIGGER `tg_pemilik_insert` BEFORE INSERT ON `pemilik` FOR EACH ROW BEGIN
  INSERT INTO pemilik_seq VALUES (NULL);
  SET NEW.idPemilik = CONCAT('p', LPAD(LAST_INSERT_ID(), 4, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `pemilik_seq`
--

DROP TABLE IF EXISTS `pemilik_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pemilik_seq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pemilik_seq`
--

LOCK TABLES `pemilik_seq` WRITE;
/*!40000 ALTER TABLE `pemilik_seq` DISABLE KEYS */;
INSERT INTO `pemilik_seq` (`id`) VALUES (1),(2),(3),(4),(5),(6),(7),(8);
/*!40000 ALTER TABLE `pemilik_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produk`
--

DROP TABLE IF EXISTS `produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produk` (
  `idProduk` varchar(64) NOT NULL,
  `namaProduk` varchar(255) NOT NULL,
  `hargaProduk` int(11) NOT NULL,
  `fotoProduk` varchar(255) NOT NULL,
  `deskripsiProduk` text NOT NULL,
  `idToko` char(6) NOT NULL,
  PRIMARY KEY (`idProduk`),
  KEY `idToko` (`idToko`),
  CONSTRAINT `produk_ibfk_1` FOREIGN KEY (`idToko`) REFERENCES `toko` (`idToko`),
  CONSTRAINT `produk_ibfk_2` FOREIGN KEY (`idToko`) REFERENCES `toko` (`idToko`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produk`
--

LOCK TABLES `produk` WRITE;
/*!40000 ALTER TABLE `produk` DISABLE KEYS */;
INSERT INTO `produk` (`idProduk`, `namaProduk`, `hargaProduk`, `fotoProduk`, `deskripsiProduk`, `idToko`) VALUES ('5d61c0c533b0e','Lemper Abon',1500,'Lemper_Abont00001.jpg','Gurih nya abon yang dibalut dengan ketan yang nikmat.','t00001'),('5d61c0f11616e','Kue Lapis',2000,'Kue_Lapist00001.jpg','Berapa lapis?? Ratusan hehehe','t00001'),('5d61c11f24964','Bolu Pelangi',2000,'Bolu_Pelangit00001.jpg','Pelangi Pelangi alangkah indahmu.. Merah hijau putih warna kue kamu','t00001'),('5d61c20ae11dd','Bolu Bakar Topping Keju',50000,'Bolu_Bakar_Topping_Kejut00001.jpg','Kalian mengira ini donat besar? Salah besar.. Ini adalah Bolu Bakar yang ditaburi keju.','t00001'),('5d61c2a822e52','Risol Pedas',2500,'Risol_Pedast00001.jpg','Risol?? Buat nyuci baju ya? | Itu Rinso -_-','t00001'),('5d61c33ac2000','Kue Pisang',2000,'Kue_Pisangt00001.jpg','Mana Pisang nya? Kok gak ada? | Pisang nya telah dibungkus daun pisang','t00001'),('5d61c58447bdb','Es Puding Kopi',15000,'Es_Puding_Kopit00002.png','Lembut nya puding dicampur dengan nikmat nya kopi','t00002'),('5d61c5ee8e105','Es Kopi Jelly',10000,'Es_Kopi_Jellyt00002.jpg','Kenyalnya jelly dicampur dengan nikmatnya kopi','t00002'),('5d61c6bcc8235','Kopi Dingin',5000,'Kopi_Dingint00002.jpg','Biarkan kopi saja yang dingin, tapi tidak untuk sikapmu','t00002'),('5d6482392b78e','Simping Kencur',11000,'Simping_Kencurt00005.jpg','Simping Kencur asli dari Purwakarta','t00005'),('5d64825948f69','Semprong',8000,'Semprongt00005.jpg','Semprong khas Purwakarta','t00005');
/*!40000 ALTER TABLE `produk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `toko`
--

DROP TABLE IF EXISTS `toko`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `toko` (
  `idToko` char(6) NOT NULL,
  `namaToko` varchar(120) NOT NULL,
  `alamatToko` varchar(150) NOT NULL,
  `idKecamatan` char(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `idKelurahan` char(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `idKategori` char(3) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `linkToko` varchar(150) DEFAULT NULL,
  `idPemilik` char(5) NOT NULL,
  `fotoToko` varchar(255) NOT NULL,
  `statusToko` enum('unverified','verified','removed') NOT NULL DEFAULT 'unverified',
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  PRIMARY KEY (`idToko`),
  KEY `idPemilik` (`idPemilik`),
  KEY `id_kelurahan` (`idKelurahan`),
  KEY `id_kecamatan` (`idKecamatan`),
  KEY `idKategori` (`idKategori`),
  CONSTRAINT `toko_ibfk_1` FOREIGN KEY (`idPemilik`) REFERENCES `pemilik` (`idPemilik`),
  CONSTRAINT `toko_ibfk_2` FOREIGN KEY (`idKelurahan`) REFERENCES `villages` (`id`),
  CONSTRAINT `toko_ibfk_3` FOREIGN KEY (`idKecamatan`) REFERENCES `districts` (`id`),
  CONSTRAINT `toko_ibfk_4` FOREIGN KEY (`idKategori`) REFERENCES `kategori` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toko`
--

LOCK TABLES `toko` WRITE;
/*!40000 ALTER TABLE `toko` DISABLE KEYS */;
INSERT INTO `toko` (`idToko`, `namaToko`, `alamatToko`, `idKecamatan`, `idKelurahan`, `idKategori`, `linkToko`, `idPemilik`, `fotoToko`, `statusToko`, `lat`, `lng`) VALUES ('t00001','Kue Basah Uni','Jl. Mawar No. 200','3214100','3214100009','k02','https://www.instagram.com/kuebasah_uni/','p0001','Kue_Basah_Uni.png','verified',-6.539315,107.445740),('t00002','Yuk Ngoding','Jl. Raya Ciganea NO. 2 Sulukuning','3214010','3214010017','k03','https://www.tokopuding.com/drinks-tokopuding','p0002','Yuk_Ngoding.JPG','verified',-6.567224,107.433945),('t00003','Salon cantik','Gang beringin no.50','3214030','3214030007','k09','','p0003','Salon_cantik.jpg','verified',-6.538717,107.448372),('t00004','Apa ya...','Perum.69','3214020','3214020004','k04','https:\\\\www.Bukalapak.co.id','p0004','Apa_ya__.','unverified',-6.489499,107.445923),('t00005','Simping Teh Ina','Jalan Mr. Dokter Kusumahatmaja','3214100','3214100008','k13','https://www.instagram.com/simping_pwk','p0006','Simping_Teh_Ina.jpg','verified',-6.555194,107.440536),('t00006','TEFA','Jalan Veteran','3214091','3214091005','k06','http://smk2.com','p0007','TEFA.jpg','verified',-7.978651,112.631783),('t00007','Test Data Usaha','Jalan Veteran 7','3214070','3214070006','k05','','p0008','Test_Data_Usaha.png','verified',-6.258555,107.146515);
/*!40000 ALTER TABLE `toko` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`u7050039`@`localhost`*/ /*!50003 TRIGGER `tg_toko_insert` BEFORE INSERT ON `toko` FOR EACH ROW BEGIN
  INSERT INTO toko_seq VALUES (NULL);
  SET NEW.idToko = CONCAT('t', LPAD(LAST_INSERT_ID(), 5, '0'));
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `toko_seq`
--

DROP TABLE IF EXISTS `toko_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `toko_seq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `toko_seq`
--

LOCK TABLES `toko_seq` WRITE;
/*!40000 ALTER TABLE `toko_seq` DISABLE KEYS */;
INSERT INTO `toko_seq` (`id`) VALUES (1),(2),(3),(4),(5),(6),(7);
/*!40000 ALTER TABLE `toko_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `villages`
--

DROP TABLE IF EXISTS `villages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `villages` (
  `id` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `district_id` char(7) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `district_id` (`district_id`),
  CONSTRAINT `villages_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `villages`
--

LOCK TABLES `villages` WRITE;
/*!40000 ALTER TABLE `villages` DISABLE KEYS */;
INSERT INTO `villages` (`id`, `district_id`, `name`) VALUES ('3214010006','3214010','Jatimekar'),('3214010007','3214010','Cikaobandung'),('3214010008','3214010','Jatiluhur'),('3214010009','3214010','Cilegong'),('3214010010','3214010','Kembangkuning'),('3214010011','3214010','Cibinong'),('3214010015','3214010','Parakanlima'),('3214010016','3214010','Cisalada'),('3214010017','3214010','Mekargalih'),('3214011001','3214011','Parungbanteng'),('3214011002','3214011','Sukasari'),('3214011003','3214011','Ciririp'),('3214011004','3214011','Kertamanah'),('3214011005','3214011','Kutamanah'),('3214020001','3214020','Tegaldatar'),('3214020002','3214020','Sinargalih'),('3214020003','3214020','Citamiang'),('3214020004','3214020','Cijati'),('3214020005','3214020','Gunungkarung'),('3214020006','3214020','Pasirjambu'),('3214020007','3214020','Ciramahilir'),('3214020008','3214020','Sukamukti'),('3214030001','3214030','Sukahaji'),('3214030002','3214030','Karoya'),('3214030003','3214030','Cadassari'),('3214030004','3214030','Cadasmekar'),('3214030005','3214030','Citalang'),('3214030006','3214030','Batutumpang'),('3214030007','3214030','Tegalwaru'),('3214030008','3214030','Tegalsari'),('3214030009','3214030','Warungjeruk'),('3214030010','3214030','Galumpit'),('3214030011','3214030','Cisarua'),('3214030012','3214030','Sukamulya'),('3214030013','3214030','Pasanggrahan'),('3214040001','3214040','Rawasari'),('3214040002','3214040','Gandasoli'),('3214040003','3214040','Gandamekar'),('3214040004','3214040','Cibogohilir'),('3214040005','3214040','Palinggihan'),('3214040006','3214040','Babakan Sari'),('3214040008','3214040','Sindangsari'),('3214040009','3214040','Citeko'),('3214040010','3214040','Citekokaler'),('3214040011','3214040','Linggarsari'),('3214040012','3214040','Pamoyanan'),('3214040013','3214040','Liunggunung'),('3214040014','3214040','Anjun'),('3214040015','3214040','Cibogo Girang'),('3214040016','3214040','Plered'),('3214040017','3214040','Sempur'),('3214050002','3214050','Cianting'),('3214050003','3214050','Pasirmunjul'),('3214050004','3214050','Cibodas'),('3214050005','3214050','Cianting Utara'),('3214050006','3214050','Sukatani'),('3214050007','3214050','Malangnengah'),('3214050008','3214050','Cilalawi'),('3214050009','3214050','Sukamaju'),('3214050010','3214050','Cipicung'),('3214050011','3214050','Tajursindang'),('3214050012','3214050','Sindanglaya'),('3214050013','3214050','Panyindangan'),('3214050014','3214050','Sukajaya'),('3214050015','3214050','Cijantung'),('3214060001','3214060','Pasirangin'),('3214060002','3214060','Nangewer'),('3214060003','3214060','Neglasari'),('3214060004','3214060','Linggasari'),('3214060005','3214060','Sawit'),('3214060006','3214060','Sirnamanah'),('3214060007','3214060','Depok'),('3214060008','3214060','Legoksari'),('3214060009','3214060','Mekarsari'),('3214060012','3214060','Gununghejo'),('3214060013','3214060','Darangdan'),('3214060014','3214060','Sadarkarya'),('3214060015','3214060','Linggamukti'),('3214060016','3214060','Cilingga'),('3214060017','3214060','Nagrak'),('3214070001','3214070','Cibingbin'),('3214070002','3214070','Bojong Timur'),('3214070003','3214070','Pasanggrahan'),('3214070004','3214070','Cihanjawar'),('3214070005','3214070','Cikeris'),('3214070006','3214070','Bojong Barat'),('3214070007','3214070','Pangkalan'),('3214070008','3214070','Sukamanah'),('3214070009','3214070','Pawenang'),('3214070010','3214070','Sindangsari'),('3214070011','3214070','Sindangpanon'),('3214070012','3214070','Cipeundeuy'),('3214070013','3214070','Cileunca'),('3214070014','3214070','Kertasari'),('3214080001','3214080','Nangerang'),('3214080002','3214080','Simpang'),('3214080003','3214080','Sakambang'),('3214080004','3214080','Nagrog'),('3214080005','3214080','Cibuntu'),('3214080007','3214080','Raharja'),('3214080008','3214080','Wanayasa'),('3214080009','3214080','Babakan'),('3214080016','3214080','Wanasari'),('3214080017','3214080','Legokhuni'),('3214080018','3214080','Ciawi'),('3214080019','3214080','Sukadami'),('3214080020','3214080','Taringgul Tonggoh'),('3214080021','3214080','Taringgul Tengah'),('3214080022','3214080','Sumurugul'),('3214081001','3214081','Pusakamulya'),('3214081002','3214081','Parakan Garokgek'),('3214081003','3214081','Ciracas'),('3214081004','3214081','Kiarapedes'),('3214081005','3214081','Cibeber'),('3214081006','3214081','Sumbersari'),('3214081007','3214081','Mekarjaya'),('3214081008','3214081','Margaluyu'),('3214081009','3214081','Gardu'),('3214081010','3214081','Taringgul Landeuh'),('3214090009','3214090','Ciherang'),('3214090010','3214090','Cidahu'),('3214090011','3214090','Pasawahan Anyar'),('3214090012','3214090','Pasawahankidul'),('3214090013','3214090','Sawah Kulon'),('3214090014','3214090','Kertajaya'),('3214090015','3214090','Lebakanyar'),('3214090016','3214090','Cihuni'),('3214090017','3214090','Warungkadu'),('3214090018','3214090','Selaawi'),('3214090019','3214090','Margasari'),('3214090020','3214090','Pasawahan'),('3214091001','3214091','Bungur Jaya'),('3214091002','3214091','Pondokbungur'),('3214091003','3214091','Salem'),('3214091004','3214091','Galudra'),('3214091005','3214091','Sukajadi'),('3214091006','3214091','Tanjungsari'),('3214091007','3214091','Salam Jaya'),('3214091008','3214091','Situ'),('3214091009','3214091','Parakansalam'),('3214091010','3214091','Salam Mulya'),('3214091011','3214091','Gurudug'),('3214100005','3214100','Sindangkasih'),('3214100006','3214100','Nageri Kidul'),('3214100007','3214100','Nageri Tengah'),('3214100008','3214100','Cipaisan'),('3214100009','3214100','Nageri Kaler'),('3214100010','3214100','Tegalmunjul'),('3214100011','3214100','Citalang'),('3214100012','3214100','Munjuljaya'),('3214100013','3214100','Ciseureuh'),('3214100016','3214100','Purwamekar'),('3214101001','3214101','Maracang'),('3214101002','3214101','Ciwareng'),('3214101003','3214101','Mulyamekar'),('3214101004','3214101','Cigelam'),('3214101005','3214101','Babakancikao'),('3214101006','3214101','Kadumekar'),('3214101007','3214101','Hegarmanah'),('3214101008','3214101','Cicadas'),('3214101009','3214101','Cilangkap'),('3214110001','3214110','Cirende'),('3214110011','3214110','Campaka'),('3214110012','3214110','Campakasari'),('3214110018','3214010','Bunder'),('3214110023','3214110','Cijunti'),('3214110024','3214110','Cisaat'),('3214110025','3214110','Cimahi'),('3214110026','3214110','Cikumpay'),('3214110027','3214110','Cijaya'),('3214110028','3214110','Kertamukti'),('3214110029','3214110','Benteng'),('3214111001','3214111','Wanawali'),('3214111002','3214111','Cikadu'),('3214111003','3214111','Cibukamanah'),('3214111004','3214111','Cirangkong'),('3214111005','3214111','Cipancur'),('3214111006','3214111','Cipinang'),('3214111007','3214111','Ciparungsari'),('3214111008','3214111','Karyamekar'),('3214111009','3214111','Cibatu'),('3214111010','3214111','Cilandak'),('3214112001','3214112','Ciwangi'),('3214112002','3214112','Cibening'),('3214112003','3214112','Bungursari'),('3214112004','3214112','Cibungur'),('3214112005','3214112','Dangdeur'),('3214112006','3214112','Wanakerta'),('3214112007','3214112','Cinangka'),('3214112008','3214112','Cikopo'),('3214112009','3214112','Karangmukti'),('3214112010','3214112','Cibodas');
/*!40000 ALTER TABLE `villages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'u7050039_umkm'
--

--
-- Dumping routines for database 'u7050039_umkm'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-25 19:51:06
