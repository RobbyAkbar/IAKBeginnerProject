<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>SIMIA - Sistem Informasi UMKM Indonesia</title>
	<link rel="shortcut icon" href="<?php echo base_url() ?>assets/img/store.png">

	<!-- Custom fonts for this template-->
	<link href="<?php echo base_url() ?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

	<!-- Custom styles for this template-->
	<link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url() ?>assets/js/jquery.min.js"></script>
	<style>
		.circle {
			padding: 13px 20px;
			border-radius: 50%;
			background-color: #4E73DF;
			color: #fff;
			max-height: 50px;
			z-index: 2;
		}

		.how-it-works.row .col-2 {
			align-self: stretch;
		}
		.how-it-works.row .col-2::after {
			content: "";
			position: absolute;
			border-left: 3px solid #4E73DF;
			z-index: 1;
		}
		.how-it-works.row .col-2.bottom::after {
			height: 50%;
			left: 50%;
			top: 50%;
		}
		.how-it-works.row .col-2.full::after {
			height: 100%;
			left: calc(50% - 3px);
		}
		.how-it-works.row .col-2.top::after {
			height: 50%;
			left: 50%;
			top: 0;
		}


		.timeline div {
			padding: 0;
			height: 40px;
		}
		.timeline hr {
			border-top: 3px solid #4E73DF;
			margin: 0;
			top: 17px;
			position: relative;
		}
		.timeline .col-2 {
			display: flex;
			overflow: hidden;
		}
		.timeline .corner {
			border: 3px solid #4E73DF;
			width: 100%;
			position: relative;
			border-radius: 15px;
		}
		.timeline .top-right {
			left: 50%;
			top: -50%;
		}
		.timeline .top-right-plus {
			left: calc(50% - 3px);
			top: -50%;
		}
		.timeline .left-bottom {
			left: -50%;
			top: calc(50% - 3px);
		}
		.timeline .top-left {
			left: -50%;
			top: -50%;
		}
		.timeline .right-bottom {
			left: calc(50% - 3px);
			top: calc(50% - 3px);
		}
	</style>
</head>
<body>
	<div class="container">
		<h2 class="pb-3 pt-2 border-bottom mb-5">Alur Pendaftaran UMKM</h2>
		<!--first section-->
		<div class="row align-items-center how-it-works d-flex">
			<div class="col-2 text-center bottom d-inline-flex justify-content-center align-items-center">
				<div class="circle font-weight-bold">1</div>
			</div>
			<div class="col-6">
				<h5><a href="<?php echo base_url('register/akun') ?>" >Daftar Akun</a></h5>
				<p>Pemilik UMKM membuat akun secara pribadi di aplikasi SIMIA (Sistem Informasi UMKM Indonesia). Lalu login untuk dapat mendaftarkan UMKM.</p>
				@user
			</div>
		</div>
		<!--path between 1-2-->
		<div class="row timeline">
			<div class="col-2">
				<div class="corner top-right"></div>
			</div>
			<div class="col-8">
				<hr/>
			</div>
			<div class="col-2">
				<div class="corner left-bottom"></div>
			</div>
		</div>
		<!--second section-->
		<div class="row align-items-center justify-content-end how-it-works d-flex">
			<div class="col-6 text-right">
				<h5><a href="<?php echo base_url('register/umkm') ?>" >Daftar UMKM</a></h5>
				<p>Setelah berhasil login, pemilik UMKM dapat mendaftarkan UMKMnya pada formulir yang telah disediakan. Yang kemudian akan diverifikasi datanya oleh admin (pemerintah).</p>
				@user
			</div>
			<div class="col-2 text-center full d-inline-flex justify-content-center align-items-center">
				<div class="circle font-weight-bold">2</div>
			</div>
		</div>
		<!--path between 2-3-->
		<div class="row timeline">
			<div class="col-2">
				<div class="corner right-bottom"></div>
			</div>
			<div class="col-8">
				<hr/>
			</div>
			<div class="col-2">
				<div class="corner top-left"></div>
			</div>
		</div>
		<!--third section-->
		<div class="row align-items-center how-it-works d-flex">
			<div class="col-2 text-center full d-inline-flex justify-content-center align-items-center">
				<div class="circle font-weight-bold">3</div>
			</div>
			<div class="col-6">
				<h5><a href="#" >Verifikasi UMKM</a></h5>
				<p>Jika data yang didaftarkan sesuai dan asli maka pemerintah merubah status UMKM menjadi telah diverifikasi. Dan UMKM sudah dapat tampil pada dashboard atau pada menu kategorinya masing-masing.</p>
				@admin
			</div>
		</div>
		<!--path between 3-4-->
		<div class="row timeline">
			<div class="col-2">
				<div class="corner top-right-plus"></div>
			</div>
			<div class="col-8">
				<hr/>
			</div>
			<div class="col-2">
				<div class="corner left-bottom"></div>
			</div>
		</div>
		<!--fourth section-->
		<div class="row align-items-center justify-content-end how-it-works d-flex">
			<div class="col-6 text-right">
				<h5><a href="<?php echo base_url('myUMKM') ?>" >Membuat Daftar Produk</a></h5>
				<p>Setelah diverifikasi oleh pemerintah, pemilik UMKM dapat membuat daftar produk yang mereka hasilkan.</p>
				@user
			</div>
			<div class="col-2 text-center full d-inline-flex justify-content-center align-items-center">
				<div class="circle font-weight-bold">4</div>
			</div>
		</div>
	</div>
</body>
</html>
