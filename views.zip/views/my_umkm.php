<!-- Begin Page Content -->
<div class="container-fluid">
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item active" aria-current="page">Produk</li>
		</ol>
	</nav>
	<?php if ($myToko->statusToko == 'unverified') { ?>
		<div class="alert alert-secondary" role="alert">
			<strong>Info!</strong> UMKM anda belum diverifikasi, tunggu maksimal 3x24 Jam (hari kerja).
		</div>
	<?php } ?>
	<?php echo $this->session->flashdata('msg') ?>
	<!-- DataTales Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold">
				<?php if ($myToko->statusToko == 'unverified') { ?> <i class="fas fa-plus-circle fa-sm"> Tambah Produk</i>
				<?php } else { ?> <a href="<?php echo base_url('myumkm/produk/add') ?>"><i class="fas fa-plus-circle fa-sm"> Tambah Produk</i></a> <?php } ?>
			</h6>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
					<tr>
						<th>#</th>
						<th>Nama Produk</th>
						<th>Harga Produk</th>
						<th>Photo Produk</th>
						<th>Deskripsi Produk</th>
						<th>Aksi</th>
					</tr>
					</thead>
					<tbody>
					<?php $no=1;
						if ($myToko->statusToko == 'verified') {
						foreach ($myProduk as $produk): ?>
						<tr>
							<th><?php echo $no++ ?></th>
							<td><?php echo $produk->namaProduk ?></td>
							<td class="text-right"><?php echo "Rp.".number_format($produk->hargaProduk,2,",",".") ?></td>
							<td class="text-center"><img src="<?php echo base_url().'uploads/foto_produk/'.$produk->fotoProduk ?>" width="64" alt=""/></td>
							<td class="small"><?php echo substr($produk->deskripsiProduk, 0, 120) ?>...</td>
							<td>
								<a href="<?php echo base_url('myumkm/produk/edit/'.$produk->idProduk) ?>" class="btn btn-small text-info"><i class="fas fa-edit"></i> Ubah</a>
								<a onclick="deleteConfirm('<?php echo base_url('myumkm/produk/delete/'.$produk->idProduk) ?>')"
								   href="#!" class="btn btn-small text-danger"><i class="fas fa-trash"></i> Hapus</a>
							</td>
						</tr>
					<?php endforeach; } ?>
					</tbody>
					<tfoot>
					<tr>
						<th>#</th>
						<th>Nama Produk</th>
						<th>Harga Produk</th>
						<th>Photo Produk</th>
						<th>Deskripsi Produk</th>
						<th>Aksi</th>
					</tr>
					</tfoot>
				</table>
			</div>
		</div>
	</div>
</div>

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy; UMKM Indonesia 2020</span>
		</div>
	</div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Siap untuk keluar?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Pilih "Keluar" di bawah ini, jika Anda ingin mengakhiri sesi Anda saat ini.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
				<a class="btn btn-primary" href="<?php echo base_url('auth/logout') ?>">Keluar</a>
			</div>
		</div>
	</div>
</div>
<!-- Logout Delete Confirmation-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Apa kamu yakin?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Data yang dihapus tidak akan bisa dikembalikan.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
				<a id="btn-delete" class="btn btn-danger" href="#">Hapus</a>
			</div>
		</div>
	</div>
</div>
<?php echo $this->session->flashdata('pesan') ?>
<script>
    function deleteConfirm(url){
        $('#btn-delete').attr('href', url);
        $('#deleteModal').modal();
    }
</script>
