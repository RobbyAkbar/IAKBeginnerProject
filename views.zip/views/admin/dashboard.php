<div class="container-fluid">
	<?php echo $this->session->flashdata('msg') ?>
	<!-- DataTales Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Daftar UMKM</h6>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
					<tr>
						<th rowspan="2" class="text-center" style="vertical-align: middle;">#</th>
						<th colspan="4" class="text-center">Informasi UMKM</th>
						<th colspan="3" class="text-center">Aksi</th>
					</tr>
					<tr>
						<th>Nama</th>
						<th>Alamat</th>
						<th>Kategori</th>
						<th>Status</th>
						<th>Detail</th>
						<th>Aktivasi</th>
						<th>Hapus</th>
					</tr>
					</thead>
					<tfoot>
					<tr>
						<th>#</th>
						<th>Nama</th>
						<th>Alamat</th>
						<th>Kategori</th>
						<th>Status</th>
						<th>Detail</th>
						<th>Aktivasi</th>
						<th>Hapus</th>
					</tr>
					</tfoot>
					<tbody>
					<?php $no=1; foreach ($toko as $item) :
						$status = $item->statusToko;
						?>
						<tr>
							<th><?php echo $no++ ?></th>
							<td><?php echo $item->namaToko ?></td>
							<td><?php echo $item->alamatToko ?></td>
							<td><?php echo $item->name ?></td>
							<td><?php
								if ($status == "unverified") echo "<span class=\"badge badge-danger\">" . $status . "</span>";
								else echo $item->statusToko ?>
							</td>
							<td><a href="#" class="btn btn-success btn-sm"><i class="fas fa-search-plus"></i></a></td>
							<td><a href="#" data-toggle="modal" data-target="#logoutEdit" data-status="<?php echo $item->statusToko ?>" data-id="<?php echo $item->idToko ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a></td>
							<td><a href="#" data-toggle="modal" data-target="#logoutRemove" data-status="<?php echo $item->statusToko ?>" data-id="<?php echo $item->idToko ?>" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<!-- Content Row -->

</div>

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy; UMKM Indonesia 2020</span>
		</div>
	</div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Siap untuk keluar?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Pilih "Keluar" di bawah ini, jika Anda ingin mengakhiri sesi Anda saat ini.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
				<a class="btn btn-primary" href="<?php echo base_url('auth/out') ?>">Keluar</a>
			</div>
		</div>
	</div>
</div>
<!-- Edit Modal-->
<div class="modal fade" id="logoutEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Ubah status UMKM</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<form id="editForm" action="" method="post" class="user">
					<input type="hidden" name="idToko" id="idToko" value="">
					<div class="form-group">
						<label for="status">Status UMKM</label>
						<select class="custom-select" id="status" name="statusToko" required>
							<option value="unverified">Belum Terverifikasi</option>
							<option value="verified">Telah Terverifikasi</option>
						</select>
						<?php echo form_error('statusToko', '<div class="text-danger small ml-2">', '</div>'); ?>
					</div>
					<div class="text-right">
						<button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
						<button type="submit" class="btn btn-primary ml-3">Ubah</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php echo $this->session->flashdata('pesan') ?>
<script type="text/javascript">
    $('#logoutEdit').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget);
        const idToko = button.data('id');
        const statusToko = button.data('status');
        const modal = $(this);
        modal.find('#editForm').attr("action", "<?php echo base_url('admin/data_umkm/edit') ?>");
        modal.find('#editForm input').val(idToko);
        if (statusToko==="verified") modal.find('#editForm div.form-group select').val("verified").attr("selected");
    })
</script>
