<!-- Begin Page Content -->
<div class="container-fluid">
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="<?php echo base_url('myUMKM') ?>">Produk</a></li>
			<li class="breadcrumb-item active" aria-current="page"><?php echo $type ?></li>
		</ol>
	</nav>
	<!-- DataTales Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold">
				<a href="<?php echo base_url('myUMKM') ?>"><i class="fas fa-arrow-left fa-sm"> Kembali</i></a>
			</h6>
		</div>
		<div class="card-body">
			<form action="<?php if ($produk!=null) echo base_url('myumkm/produk/edit/'.$produk->idProduk); else echo base_url('myumkm/produk/add'); ?>" method="post" enctype="multipart/form-data" class="user">
				<?php if ($produk!=null) { ?>
					<input type="hidden" name="idProduk" value="<?php if ($produk!=null) echo $produk->idProduk?>" />
					<input type="hidden" name="old_image" value="<?php if ($produk!=null) echo $produk->fotoProduk?>" />
				<?php } ?>
				<div class="form-group">
					<label for="validationProductName">Nama Produk</label>
					<input class="form-control" type="text" id="validationProductName" name="namaProduk" placeholder="Masukan nama produk" value="<?php if ($produk!=null) echo $produk->namaProduk ?>" />
					<?php echo form_error('namaProduk', '<div class="text-danger small ml-2">', '</div>'); ?>
				</div>
				<div class="form-group">
					<label for="validationProductPrice">Harga Produk</label>
					<input class="form-control" type="number" id="validationProductPrice" name="hargaProduk" min="0" placeholder="Masukan harga produk" value="<?php if ($produk!=null) echo $produk->hargaProduk ?>" />
					<?php echo form_error('hargaProduk', '<div class="text-danger small ml-2">', '</div>'); ?>
				</div>
				<div class="form-group">
					<label for="validationProductDescription">Deskripsi Produk</label>
					<textarea class="form-control" id="validationProductDescription" placeholder="Masukan deskripsi produk..." name="deskripsiProduk"><?php if ($produk!=null) echo $produk->deskripsiProduk ?></textarea>
					<?php echo form_error('deskripsiProduk', '<div class="text-danger small ml-2">', '</div>'); ?>
				</div>
				<div class="custom-file">
					<input type="file" class="form-control form-control-user custom-file-input" id="validatedCustomFile" accept="image/*" name="fotoProduk" <?php if ($produk==null) echo "required" ?>/>
					<label class="custom-file-label" for="validatedCustomFile"><small>Pilih photo produk<?php if ($produk!=null) echo " jika ingin diganti" ?>...</small></label>
				</div>
				<button class="btn btn-primary" type="submit">Simpan</button>
			</form>
		</div>
	</div>
</div>

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy; UMKM Indonesia 2020</span>
		</div>
	</div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Siap untuk keluar?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Pilih "Keluar" di bawah ini, jika Anda ingin mengakhiri sesi Anda saat ini.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
				<a class="btn btn-primary" href="<?php echo base_url('auth/logout') ?>">Keluar</a>
			</div>
		</div>
	</div>
</div>
