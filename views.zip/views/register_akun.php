<body class="bg-gradient-primary">

<div class="container">

	<div class="card o-hidden border-0 shadow-lg my-5 mx-auto">
		<div class="card-body p-0">
			<!-- Nested Row within Card Body -->
			<div class="row">
				<div class="col-lg-5 d-none d-lg-block align-self-center">
					<img class="img-fluid px-3 px-sm-4 mt-3 mb-4" src="<?php echo base_url('/assets/img/resume.svg') ?>" alt="">
					<footer class="sticky-footer bg-white">
						<div class="container my-auto">
							<div class="copyright text-center my-auto">
								<span>Copyright &copy; UMKM Indonesia 2020</span>
							</div>
						</div>
					</footer>
				</div>
				<div class="col-lg-7">
					<div class="p-5">
						<div class="text-center">
							<h1 class="h4 text-gray-900 mb-4">Buat sebuah Akun!</h1>
						</div>
						<?php echo $this->session->flashdata('pesan') ?>
						<form action="<?php echo base_url('register/akun') ?>" method="post" enctype="multipart/form-data" class="user">
							<div class="form-group">
								<input type="text" class="form-control form-control-user" id="exampleInputFullName" placeholder="Nama Anda" name="namaPemilik">
								<?php echo form_error('namaPemilik', '<div class="text-danger small ml-2">', '</div>'); ?>
							</div>
							<div class="form-group">
								<input type="text" class="form-control form-control-user" id="exampleInputNumberPhone" placeholder="Nomor Hp | contoh.62xxx" name="noHp">
								<?php echo form_error('noHp', '<div class="text-danger small ml-2">', '</div>'); ?>
							</div>
							<div class="form-group">
								<input type="email" class="form-control form-control-user" id="exampleInputEmail" placeholder="Alamat Email" name="emailPemilik">
								<?php echo form_error('emailPemilik', '<div class="text-danger small ml-2">', '</div>'); ?>
							</div>
							<div class="form-group row">
								<div class="col-sm-6 mb-3 mb-sm-0">
									<input type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password" name="password1">
									<?php echo form_error('password1', '<div class="text-danger small ml-2">', '</div>'); ?>
								</div>
								<div class="col-sm-6">
									<input type="password" class="form-control form-control-user" id="exampleRepeatPassword" placeholder="Ulangi Password" name="password2">
								</div>
							</div>
							<div class="form-group">
								<textarea class="form-control form-control-user" id="exampleInputHomeAddress" placeholder="Alamat Rumah" name="alamatPemilik"></textarea>
								<?php echo form_error('alamatPemilik', '<div class="text-danger small ml-2">', '</div>'); ?>
							</div>
							<div class="form-group">
								<input type="text" class="form-control form-control-user" id="exampleInputNumberID" placeholder="Nomor Induk Kependudukan" name="nikPemilik">
								<?php echo form_error('nikPemilik', '<div class="text-danger small ml-2">', '</div>'); ?>
							</div>
							<div class="custom-file">
								<input type="file" class="form-control form-control-user custom-file-input" id="validatedCustomFile" accept="image/*" name="fotoKtp" required>
								<label class="custom-file-label" for="validatedCustomFile"><small>Foto KTP...</small></label>
							</div>
							<button type="submit" class="btn btn-primary btn-user btn-block">
								Daftar Akun
							</button>
						</form>
						<hr>
						<div class="text-center">
							<a class="small" href="<?php echo base_url('dashboard') ?>">Kembali ke Beranda</a>
						</div>
						<div class="text-center">
							<a class="small" href="<?php echo base_url('auth/login') ?>">Sudah punya akun? Silahkan masuk!</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>
