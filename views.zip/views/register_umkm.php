<body style="background-size: 500px; background-image: url('<?php echo base_url('/assets/img/business.svg') ?>'); background-position: bottom right; background-repeat: no-repeat;">

<div class="container">

	<!-- Outer Row -->
	<div class="row justify-content-center">

		<div class="col-xl-10 col-lg-12 col-md-9">

			<div class="card o-hidden border-0 shadow-lg my-5">
				<div class="card-body p-0">
					<!-- Nested Row within Card Body -->
					<div class="row">
						<div class="col-lg-12">
							<div class="p-5">
								<div class="text-center">
									<h1 class="h4 text-gray-900 mb-4">Daftarkan UMKM Anda!</h1>
								</div>
								<?php echo $this->session->flashdata('pesan') ?>
								<form action="<?php echo base_url('register/umkm') ?>" method="post" enctype="multipart/form-data" class="user">
									<div class="form-group">
										<label for="validationStoreName">Nama Usaha</label>
										<input type="text" class="form-control" id="validationStoreName" placeholder="Nama Usaha" name="namaToko">
										<?php echo form_error('namaToko', '<div class="text-danger small ml-2">', '</div>'); ?>
									</div>
									<div class="form-row">
										<div class="form-group col-md-10">
											<label for="validationStoreAddress">Alamat Usaha</label>
											<textarea class="form-control" id="validationStoreAddress" placeholder="Alamat Usaha" name="alamatToko"></textarea>
											<?php echo form_error('alamatToko', '<div class="text-danger small ml-2">', '</div>'); ?>
										</div>
										<div class="form-group col-md-2 align-self-center mt-4">
											<a href="#" data-toggle="modal" data-target="#mapModal"><i class="fas fa-map-pin fa-sm"> Pilih Lokasi</i></a>
											<input type="hidden" id="default_latitude" placeholder="Latitude" name="latitude"/>
											<input type="hidden" id="default_longitude" placeholder="Longitude" name="longitude"/>
											<?php echo form_error('latitude', '<div class="text-danger small ml-2">', '</div>'); ?>
											<?php echo form_error('longitude', '<div class="text-danger small ml-2">', '</div>'); ?>
										</div>
									</div>
									<div class="form-row">
										<div class="form-group col-md-6">
											<label for="kecamatan">Kecamatan</label>
											<select id="kecamatan" class="custom-select" name="idKecamatan"></select>
											<?php echo form_error('idKecamatan', '<div class="text-danger small ml-2">', '</div>'); ?>
										</div>
										<div class="form-group col-md-6">
											<label for="kelurahan">Kelurahan</label>
											<select id="kelurahan" class="custom-select" name="idKelurahan"></select>
											<?php echo form_error('idKelurahan', '<div class="text-danger small ml-2">', '</div>'); ?>
										</div>
									</div>
									<div class="form-group">
										<label for="category">Jenis Kategori Usaha</label>
										<select class="custom-select" id="category" name="idKategori"></select>
										<?php echo form_error('idKategori', '<div class="text-danger small ml-2">', '</div>'); ?>
									</div>
									<div class="form-group">
										<label for="validationLink">Tautan Online (Opsional)</label>
										<input type="url" class="form-control" id="validationLink" placeholder="Link Website / E-Commerce" name="linkToko">
									</div>
									<div class="custom-file">
										<input type="file" class="form-control form-control-user custom-file-input" id="validatedCustomFile" accept="image/*" name="fotoToko" required>
										<label class="custom-file-label" for="validatedCustomFile"><small>Foto Toko...</small></label>
									</div>
									<button type="submit" class="btn btn-primary btn-block">Daftar UMKM</button>
								</form>
								<hr>
								<div class="text-center">
									<a class="small" href="<?php echo base_url('dashboard') ?>">Kembali ke Beranda</a>
								</div>
								<footer class="sticky-footer bg-white">
									<div class="container my-auto">
										<div class="copyright text-center my-auto">
											<span>Copyright &copy; UMKM Indonesia 2020</span>
										</div>
									</div>
								</footer>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>

	</div>

</div>
<!-- Map Modal-->
<div class="modal fade" id="mapModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Pilih lokasi UMKM anda</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<input id="pac-input" class="controls" type="text" placeholder="Cari Lokasi">
				<div id="map"></div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary" type="button" data-dismiss="modal">Pilih</button>
			</div>
		</div>
	</div>
</div>
<script>
    function initialize() {
        const mapOptions = {
            zoom: 11,
            center: new google.maps.LatLng(-6.539049, 107.444538),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            streetViewControl: false,
            mapTypeControl: false
        };
        map = new google.maps.Map(document.getElementById('map'),
            mapOptions);
        google.maps.event.addListener(map, 'center_changed', function() {
            document.getElementById('default_latitude').value = map.getCenter().lat();
            document.getElementById('default_longitude').value = map.getCenter().lng();
        });
        $('<div/>').addClass('centerMarker').appendTo(map.getDiv())
        //do something onclick
            .click(function(){
                const that = $(this);
                if(!that.data('win')){
                    that.data('win',new google.maps.InfoWindow({content:'this is the center'}));
                    that.data('win').bindTo('position',map,'center');
                }
                that.data('win').open(map);
            });

        // Create the search box and link it to the UI element.
        const input = document.getElementById('pac-input');
        const searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
        map.addListener('bounds_changed', function() {
            searchBox.setBounds(map.getBounds());
        });

        let markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
        searchBox.addListener('places_changed', function() {
            const places = searchBox.getPlaces();

            if (places.length == 0) {
                return;
            }

            // Clear out the old markers.
            markers.forEach(function(marker) {
                marker.setMap(null);
            });
            markers = [];

            // For each place, get the icon, name and location.
            const bounds = new google.maps.LatLngBounds();
            places.forEach(function(place) {
                if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                }

                if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                } else {
                    bounds.extend(place.geometry.location);
                }
            });
            map.fitBounds(bounds);
        });

    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDpsSPtYu3jdwpptEvKjIf89aOph2wdYEg&libraries=places&callback=initialize" async defer></script>
<script>
    $(document).ready(function() {
        $("#kecamatan").html('');
        $("#kelurahan").html('');
        $("#category").html('');
        $("#kecamatan").append('<option value="">Pilih Kecamatan</option>');
        $("#kelurahan").append('<option value="">Pilih Kelurahan</option>');
        $("#category").append('<option value="">Pilih Kategori Usaha</option>');
        $.ajax({
            type: 'GET',
            url: '<?php echo base_url('daftar/kecamatan');?>',
            dataType: 'JSON',
            success: function(data) {
                for (let i = 0; i < data.length; i++)
                    $("#kecamatan").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
        });
        $.ajax({
            type: 'GET',
            url: '<?php echo base_url('daftar/kategori');?>',
            dataType: 'JSON',
            success: function(data) {
                for (let i = 0; i < data.length; i++)
                    $("#category").append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
            }
        });
    });
    $("#kecamatan").change(function(){
        const id_kec = $("#kecamatan").val();
        $("#kelurahan").html('');
        $("#kelurahan").append('<option value="">Pilih Kelurahan</option>');
        $.ajax({
            type: 'POST',
            url : '<?php echo base_url('daftar/kelurahan');?>',
            dataType : 'json',
            data : {id_kec:id_kec},
            success : function(data){
                for(let i = 0; i < data.length; i++)
                    $("#kelurahan").append('<option value="'+ data[i].id +'">' + data[i].name + '</option>');
            }
        });
    });
</script>
