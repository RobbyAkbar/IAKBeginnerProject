<div class="container-fluid">
	<h1 class="h3 mb-0 text-gray-800">Hasil Pencarian...</h1>
	<?php if ($hasil==null) { ?>
		<div class="text-center">
			<img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="<?php echo base_url('/assets/img/empty.svg') ?>" alt="">
		</div>
	<?php } ?>
	<div class="row text-center ml-5 mr-5">
		<?php foreach ($hasil as $item) :?>
			<div class="card m-3" style="width: 16rem;">
				<img src="<?php echo base_url().'/uploads/foto_toko/'.$item->fotoToko ?>" class="img-thumbnail" alt="..." style="object-fit: cover; object-position: center; height: 200px;">
				<div class="card-body">
					<h5 class="card-title"><a href="<?php echo base_url('dashboard/umkm/').$item->idToko ?>"><?php echo $item->namaToko ?></a></h5>
					<small><?php echo $item->alamatToko ?></small><br>
					<span class="badge badge-pill badge-success mb-3"><?php echo $item->name ?></span>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</div>

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy; UMKM Indonesia 2020</span>
		</div>
	</div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Siap untuk keluar?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Pilih "Keluar" di bawah ini, jika Anda ingin mengakhiri sesi Anda saat ini.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
				<a class="btn btn-primary" href="<?php echo base_url('auth/logout') ?>">Keluar</a>
			</div>
		</div>
	</div>
</div>
