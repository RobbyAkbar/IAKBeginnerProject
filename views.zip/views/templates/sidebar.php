<body id="page-top" class="sidebar-toggled">

<!-- Page Wrapper -->
<div id="wrapper">

	<!-- Sidebar -->
	<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled" id="accordionSidebar">

		<!-- Sidebar - Brand -->
		<a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url('dashboard') ?>">
			<div class="sidebar-brand-icon">
				<img src="<?php echo base_url() ?>assets/img/store.png" width="40px" alt="siumata"/>
			</div>
			<div class="sidebar-brand-text mx-3">UMKM Indonesia</div>
		</a>

		<!-- Divider -->
		<hr class="sidebar-divider my-0">

		<!-- Nav Item - Dashboard -->
		<li class="nav-item <?php if ($menu == "Dashboard") echo "active"?>">
			<a class="nav-link" href="<?php echo base_url('dashboard') ?>">
				<i class="fas fa-fw fa-home"></i>
				<span>Beranda</span></a>
		</li>
		<?php if ($this->session->userdata('idToko') != null) { ?>
		<li class="nav-item <?php if ($menu == "myUMKM") echo "active"?>">
			<a class="nav-link" href="<?php echo base_url('myUMKM') ?>">
				<i class="fas fa-fw fa-store-alt"></i>
				<span>UMKM Saya</span></a>
		</li>
		<?php } ?>

		<!-- Divider -->
		<hr class="sidebar-divider">

		<!-- Heading -->
		<div class="sidebar-heading">
			Kategori
		</div>

		<div style="height: 350px; overflow-x:hidden;" id="umkmKategori">
			<!-- Nav Item -->
			<li class="nav-item <?php if ($menu == "Agribisnis") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/agribisnis') ?>">
					<i class="fas fa-fw fa-tractor"></i>
					<span>Agribisnis</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Makanan") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/makanan') ?>">
					<i class="fas fa-fw fa-utensils"></i>
					<span>Makanan</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Minuman") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/minuman') ?>">
					<i class="fas fa-fw fa-coffee"></i>
					<span>Minuman</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Makanan & Minuman") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/mami') ?>">
					<i class="fas fa-fw fa-utensils"></i>
					<span>Makanan & Minuman</span>
					<i class="fas fa-fw fa-coffee"></i>
				</a>
			</li>
			<li class="nav-item <?php if ($menu == "Fashion") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/fashion') ?>">
					<i class="fas fa-fw fa-tshirt"></i>
					<span>Fashion</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Craft") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/craft') ?>">
					<i class="fas fa-fw fa-diagnoses"></i>
					<span>Craft</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Aksesoris") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/aksesoris') ?>">
					<i class="fas fa-fw fa-puzzle-piece"></i>
					<span>Aksesoris</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Bordir") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/bordir') ?>">
					<i class="fas fa-fw fa-chess-board"></i>
					<span>Bordir</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Jasa Salon") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/salon') ?>">
					<i class="fas fa-fw fa-mask"></i>
					<span>Jasa Salon</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Batik") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/batik') ?>">
					<i class="fas fa-fw fa-stroopwafel"></i>
					<span>Batik</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Mebel") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/mebel') ?>">
					<i class="fas fa-fw fa-couch"></i>
					<span>Mebel</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Konveksi") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/konveksi') ?>">
					<i class="fas fa-fw fa-cut"></i>
					<span>Konveksi</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Kuliner") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/kuliner') ?>">
					<i class="fas fa-fw fa-mortar-pestle"></i>
					<span>Kuliner</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Obat-Obatan") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/obat') ?>">
					<i class="fas fa-fw fa-capsules"></i>
					<span>Obat-Obatan</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Industri") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/industri') ?>">
					<i class="fas fa-fw fa-industry"></i>
					<span>Industri</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Dekorasi") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/dekorasi') ?>">
					<i class="fas fa-fw fa-holly-berry"></i>
					<span>Dekorasi</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Garment") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/garment') ?>">
					<i class="fas fa-fw fa-warehouse"></i>
					<span>Garment</span></a>
			</li>
			<li class="nav-item <?php if ($menu == "Toko atau Retail") echo "active"?>">
				<a class="nav-link" href="<?php echo base_url('dashboard/retail') ?>">
					<i class="fas fa-fw fa-tags"></i>
					<span>Toko atau Retail</span></a>
			</li>
		</div>

		<!-- Divider -->
		<hr class="sidebar-divider my-0">

		<li class="nav-item">
			<a class="nav-link" href="<?php echo base_url('alur') ?>">
				<i class="fas fa-fw fa-stream"></i>
				<span>Alur Pendaftaran</span></a>
		</li>

		<hr class="sidebar-divider d-none d-md-block">

		<!-- Sidebar Toggler (Sidebar) -->
		<div class="text-center d-none d-md-inline">
			<button class="rounded-circle border-0" id="sidebarToggle"></button>
		</div>

	</ul>
	<!-- End of Sidebar -->

	<!-- Content Wrapper -->
	<div id="content-wrapper" class="d-flex flex-column">

		<!-- Main Content -->
		<div id="content">

			<!-- Topbar -->
			<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

				<!-- Sidebar Toggle (Topbar) -->
				<button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
					<i class="fa fa-bars"></i>
				</button>

				<!-- Topbar Search -->
				<form action="<?php echo base_url('dashboard/search') ?>" method="get" class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
					<div class="input-group">
						<input type="text" class="form-control bg-light border-0 small" placeholder="Cari kata..." aria-label="Search" aria-describedby="basic-addon2" name="keyword" required>
						<div class="input-group-append">
							<button class="btn btn-primary" type="submit">
								<i class="fas fa-search fa-sm"></i>
							</button>
						</div>
					</div>
				</form>

				<!-- Topbar Navbar -->
				<ul class="navbar-nav ml-auto">

					<!-- Nav Item - Search Dropdown (Visible Only XS) -->
					<li class="nav-item dropdown no-arrow d-sm-none">
						<a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<i class="fas fa-search fa-fw"></i>
						</a>
						<!-- Dropdown - Messages -->
						<div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
							<form action="<?php echo base_url('dashboard/search') ?>" method="get" class="form-inline mr-auto w-100 navbar-search">
								<div class="input-group">
									<input type="text" class="form-control bg-light border-0 small" placeholder="Cari kata..." aria-label="Search" aria-describedby="basic-addon2" name="keyword" required>
									<div class="input-group-append">
										<button class="btn btn-primary" type="submit">
											<i class="fas fa-search fa-sm"></i>
										</button>
									</div>
								</div>
							</form>
						</div>
					</li>

					<?php if ($this->session->userdata('username')) {
					if ($this->session->userdata('hak_akses')!=777){
					if ($this->session->userdata('idToko') == null) { ?>
					<li class="nav-item dropdown no-arrow">
						<a href="<?php echo base_url('register/umkm') ?>" class="text-primary nav-link dropdown-toggle"><i
								class="fas fa-plus-circle fa-sm"> Daftar UMKM</i></a>
					</li>
					<?php }
					} else { ?>
						<li class="nav-item dropdown no-arrow">
							<a href="<?php echo base_url('admin/dashboard_admin') ?>" class="text-primary nav-link dropdown-toggle"><i class="fas fa-user-cog fa-sm"> Admin Control</i></a>
						</li>
					<?php } ?>
						<div class="topbar-divider d-none d-sm-block"></div>
						<!-- Nav Item - User Information -->
						<li class="nav-item dropdown no-arrow">
							<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<span class="mr-2 d-none d-lg-inline text-gray-600 small">Halo, <?php echo $this->session->userdata('username') ?></span>
								<img class="img-profile rounded-circle" src="<?php echo base_url().'/assets/img/profile_pic.svg' ?>">
							</a>
							<!-- Dropdown - User Information -->
							<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
								<a class="dropdown-item" href="#">
									<i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
									Profile
								</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
									<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
									Keluar
								</a>
							</div>
						</li>
					<?php } else { ?>
						<div class="topbar-divider d-none d-sm-block"></div>
						<li class="nav-item dropdown no-arrow">
							<a href="<?php echo base_url('auth/login') ?>" class="text-primary nav-link dropdown-toggle"><i class="fas fa-sign-in-alt fa-sm"> Masuk</i></a>
						</li>
					<?php } ?>

				</ul>

			</nav>
			<!-- End of Topbar -->
