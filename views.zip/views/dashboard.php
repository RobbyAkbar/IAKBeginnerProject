			<!-- Begin Page Content -->
			<div class="container-fluid">

				<!-- Page Heading -->
				<div class="d-sm-flex align-items-center justify-content-between mb-4">
					<h1 class="h3 mb-0 text-gray-800">UMKM Terdaftar</h1>
					<div class="dropdown">
						<a class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort-amount-down-alt fa-sm text-white-50"></i> Urut Berdasarkan</a>
						<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
							<a class="dropdown-item" href="#">Nama UMKM</a>
							<a class="dropdown-item" href="#">Tanggal Terdaftar</a>
						</div>
					</div>
				</div>

				<nav aria-label="breadcrumb">
					<ol class="breadcrumb">
						<?php if ($menu!="Dashboard"){ ?>
							<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard') ?>">Beranda</a></li>
							<li class="breadcrumb-item active" aria-current="page"><?php echo $menu ?></li>
						<?php } else { ?>
							<li class="breadcrumb-item active" aria-current="page">Beranda</li>
						<?php } ?>
					</ol>
				</nav>

				<?php if ($menu=="Dashboard") { ?>
				<div class="row">
					<div class="col-xl-6">
						<!-- Bar Chart -->
						<div class="card shadow mb-4">
							<div class="card-header py-3">
								<h6 class="m-0 font-weight-bpold text-primary">Jumlah UMKM Berdasarkan Kategori Usaha</h6>
							</div>
							<div class="card-body" style="height: 600px">
								<canvas id="horizontalBarCategory"></canvas>
							</div>
						</div>
					</div>
					<div class="col-xl-6">
						<!-- Bar Chart -->
						<div class="card shadow mb-4">
							<div class="card-header py-3">
								<h6 class="m-0 font-weight-bpold text-primary">Jumlah UMKM Berdasarkan Lokasi Kecamatan</h6>
							</div>
							<div class="card-body" style="height: 600px">
								<canvas id="horizontalBarDistrict"></canvas>
							</div>
						</div>
					</div>
				</div>
				<?php } ?>

				<?php if ($toko==null) { ?>
				<div class="text-center">
					<img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="<?php echo base_url('/assets/img/empty.svg') ?>" alt="">
				</div>
				<?php } ?>

				<div class="row text-center ml-5 mr-5">
					<?php foreach ($toko as $item) :?>
						<div class="card m-3" style="width: 16rem;">
							<img src="<?php echo base_url().'/uploads/foto_toko/'.$item->fotoToko ?>" class="img-thumbnail" alt="..." style="object-fit: cover; object-position: center; height: 200px;">
							<div class="card-body">
								<h5 class="card-title"><a href="<?php echo base_url('dashboard/umkm/').$item->idToko ?>"><?php echo $item->namaToko ?></a></h5>
								<small><?php echo $item->alamatToko ?></small><br>
								<span class="badge badge-pill badge-success mb-3"><?php echo $item->name ?></span>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="row">
					<div class="col">
						<!--Tampilkan pagination-->
						<?php echo $pagination; ?>
					</div>
				</div>

			</div>
			<!-- /.container-fluid -->

		</div>
		<!-- End of Main Content -->

		<!-- Footer -->
		<footer class="sticky-footer bg-white">
			<div class="container my-auto">
				<div class="copyright text-center my-auto">
					<span>Copyright &copy; UMKM Indonesia 2020</span>
				</div>
			</div>
		</footer>
		<!-- End of Footer -->

	</div>
	<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Siap untuk keluar?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Pilih "Keluar" di bawah ini, jika Anda ingin mengakhiri sesi Anda saat ini.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
				<a class="btn btn-primary" href="<?php echo base_url('auth/logout') ?>">Keluar</a>
			</div>
		</div>
	</div>
</div>
			<?php echo $this->session->flashdata('pesan') ?>
<script>
    const el = document.getElementById("umkmKategori");
    el.scrollTop = <?php echo $scroll ?>;
</script>
<script src="<?php echo base_url() ?>assets/vendor/chart.js/Chart.min.js"></script>
<script>
	<?php if ($menu=="Dashboard") { ?>
    new Chart(document.getElementById("horizontalBarCategory"), {
        "type": "horizontalBar",
        "data": {
            "labels": ["Agribisnis", "Aksesoris", "Batik", "Bordir", "Craft", "Dekorasi", "Fashion", "Garment", "Industri",
                "Jasa Salon", "Konveksi", "Kuliner", "Makanan", "Makanan & Minuman", "Mebel", "Minuman", "Obat-Obatan", "Toko atau Retail"],
            "datasets": [{
                "label": "Jumlah UMKM",
                "data": [
					<?php
					foreach ($kategori as $item) :
						$newKategori[] = $item->jumlah;
					endforeach;
					$res_arr = implode(',',$newKategori);
					print_r($res_arr);
					?>
                ],
                "fill": false,
                "backgroundColor": "#4e73df",
                "hoverBackgroundColor": "#2e59d9",
                "borderColor": "#4e73df",
                "borderWidth": 1
            }]
        },
        "options": {
            "scales": {
                "xAxes": [{
                    "ticks": {
                        "beginAtZero": true
                    }
                }]
            },
            "maintainAspectRatio": false
        }
    });
    new Chart(document.getElementById("horizontalBarDistrict"), {
        "type": "horizontalBar",
        "data": {
            "labels": ["Babakancikao", "Bojong", "Bungursari", "Campaka", "Cibatu", "Darangdan", "Jatiluhur", "Kiarapedes", "Maniis",
                "Pasawahan", "Plered", "Pondok Salam", "Purwakarta", "Sukasari", "Sukatani", "Tegal Waru", "Wanayasa"],
            "datasets": [{
                "label": "Jumlah UMKM",
                "data": [
					<?php
					foreach ($kecamatan as $item) :
						$newKecamatan[] = $item->jumlah;
					endforeach;
					$res_arr = implode(',',$newKecamatan);
					print_r($res_arr);
					?>
                ],
                "fill": false,
                "backgroundColor": "#4e73df",
                "hoverBackgroundColor": "#2e59d9",
                "borderColor": "#4e73df",
                "borderWidth": 1
            }]
        },
        "options": {
            "scales": {
                "xAxes": [{
                    "ticks": {
                        "beginAtZero": true
                    }
                }]
            },
            "maintainAspectRatio": false
        }
    });
	<?php } ?>
</script>
